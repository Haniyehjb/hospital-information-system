#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QSqlQuery>
#include <QSqlError>
#include <QMessageBox>
#include <QVariant>
#include <QVBoxLayout>
#include <QTabWidget>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    // 1. Create Tabs programmatically
    QTabWidget *tabWidget = new QTabWidget(this);
    QWidget *tabRegister = new QWidget();
    QWidget *tabDepartments = new QWidget();

    tabWidget->addTab(tabRegister, "Register Patient");
    tabWidget->addTab(tabDepartments, "Departments");

    QVBoxLayout *registerLayout = new QVBoxLayout(tabRegister);

    // 2. Initialize UI Elements
    txtNationalCode = new QLineEdit(this);
    firstNameEdit = new QLineEdit(this);
    lastNameEdit = new QLineEdit(this);

    dateBirth = new QDateEdit(this);
    dateBirth->setCalendarPopup(true);

    comboGender = new QComboBox(this);
    comboGender->addItem("Male");
    comboGender->addItem("Female");

    txtPhoneNumber = new QLineEdit(this);
    btnRegister = new QPushButton("Register Patient", this);

    // 3. Add Elements to Layout
    registerLayout->addWidget(new QLabel("National Code:"));
    registerLayout->addWidget(txtNationalCode);
    registerLayout->addWidget(new QLabel("First Name:"));
    registerLayout->addWidget(firstNameEdit);
    registerLayout->addWidget(new QLabel("Last Name:"));
    registerLayout->addWidget(lastNameEdit);
    registerLayout->addWidget(new QLabel("Birth Date:"));
    registerLayout->addWidget(dateBirth);
    registerLayout->addWidget(new QLabel("Gender:"));
    registerLayout->addWidget(comboGender);
    registerLayout->addWidget(new QLabel("Phone Number:"));
    registerLayout->addWidget(txtPhoneNumber);
    registerLayout->addWidget(btnRegister);

    // 4. Setup Department Tab
    QVBoxLayout *deptLayout = new QVBoxLayout(tabDepartments);
    comboDepartments = new QComboBox(this);
    deptLayout->addWidget(new QLabel("Select Department:"));
    deptLayout->addWidget(comboDepartments);
    // ساخت تب پزشکان بر اساس نمودار ER
    QWidget *tabDoctors = new QWidget();
    tabWidget->addTab(tabDoctors, "Register Doctor");

    QVBoxLayout *doctorsLayout = new QVBoxLayout(tabDoctors);

    txtDocFirstName = new QLineEdit(this);
    txtDocLastName = new QLineEdit(this);
    txtSpecialty = new QLineEdit(this);
    txtDocPhone = new QLineEdit(this);
    comboDocDepartment = new QComboBox(this);
    btnRegisterDoctor = new QPushButton("Register Doctor", this);

    doctorsLayout->addWidget(new QLabel("First Name (نام):"));
    doctorsLayout->addWidget(txtDocFirstName);
    doctorsLayout->addWidget(new QLabel("Last Name (نام خانوادگی):"));
    doctorsLayout->addWidget(txtDocLastName);
    doctorsLayout->addWidget(new QLabel("Specialty (تخصص):"));
    doctorsLayout->addWidget(txtSpecialty);
    doctorsLayout->addWidget(new QLabel("Phone Number (تلفن):"));
    doctorsLayout->addWidget(txtDocPhone);
    doctorsLayout->addWidget(new QLabel("Department (بخش):"));
    doctorsLayout->addWidget(comboDocDepartment);
    doctorsLayout->addWidget(btnRegisterDoctor);

    connect(btnRegisterDoctor, &QPushButton::clicked, this, &MainWindow::handleRegisterDoctor);

    // ---- ساخت تب مدیریت و رزرواسیون هوشمند نوبت‌ها ----
    QWidget *tabAppointments = new QWidget();
    tabWidget->addTab(tabAppointments, "Appointments");

    QVBoxLayout *appLayout = new QVBoxLayout(tabAppointments);

    // بخش اول: پنل پزشک (افزودن زمان‌های خالی)
    appLayout->addWidget(new QLabel("<h3>[ پنل پزشک: تعریف زمان‌های خالی ]</h3>"));
    comboSlotDoctor = new QComboBox(this);
    txtNewSlotDateTime = new QLineEdit(this);
    txtNewSlotDateTime->setPlaceholderText("YYYY-MM-DD HH:MM:SS");
    btnCreateSlot = new QPushButton("Add Available Slot (افزودن نوبت خالی)", this);

    appLayout->addWidget(new QLabel("Select Doctor:"));
    appLayout->addWidget(comboSlotDoctor);
    appLayout->addWidget(new QLabel("Enter Date & Time:"));
    appLayout->addWidget(txtNewSlotDateTime);
    appLayout->addWidget(btnCreateSlot);

    appLayout->addWidget(new QLabel("<hr>")); // خط جداکننده

    // بخش دوم: پنل بیمار (رزرو نوبت‌های موجود)
    appLayout->addWidget(new QLabel("<h3>[ پنل بیمار: رزرو نوبت ]</h3>"));
    comboAppPatient = new QComboBox(this);
    comboAppDoctor = new QComboBox(this);
    comboAppSlots = new QComboBox(this);
    btnRegisterAppointment = new QPushButton("Book Appointment (رزرو نوبت)", this);

    appLayout->addWidget(new QLabel("Select Patient (انتخاب بیمار):"));
    appLayout->addWidget(comboAppPatient);
    appLayout->addWidget(new QLabel("Select Doctor (انتخاب پزشک):"));
    appLayout->addWidget(comboAppDoctor);
    appLayout->addWidget(new QLabel("Select Available Time (انتخاب زمان‌های خالی):"));
    appLayout->addWidget(comboAppSlots);
    appLayout->addWidget(btnRegisterAppointment);

    // اتصال سیگنال‌ها و اسلات‌های بخش نوبت‌دهی
    connect(btnCreateSlot, &QPushButton::clicked, this, &MainWindow::handleCreateSlot);
    connect(btnRegisterAppointment, &QPushButton::clicked, this, &MainWindow::handleRegisterAppointment);
    connect(comboAppDoctor, &QComboBox::currentTextChanged, this, &MainWindow::handleDoctorSelectionChanged);

    // لود اولیه بیماران و پزشکان در کمبوباکس‌ها
    QSqlQuery qPatients("SELECT PatientID, FirstName + ' ' + LastName FROM Patients");
    while (qPatients.next()) {
        comboAppPatient->addItem(qPatients.value(1).toString(), qPatients.value(0).toInt());
    }

    QSqlQuery qDoctors("SELECT DoctorID, FirstName + ' ' + LastName FROM Doctors");
    while (qDoctors.next()) {
        comboSlotDoctor->addItem(qDoctors.value(1).toString(), qDoctors.value(0).toInt());
        comboAppDoctor->addItem(qDoctors.value(1).toString(), qDoctors.value(0).toInt());
    }

    // ---- ساخت تب نسخه الکترونیک و اقلام نسخه ----
    QWidget *tabPrescriptions = new QWidget();
    tabWidget->addTab(tabPrescriptions, "E-Prescription");

    QVBoxLayout *prescLayout = new QVBoxLayout(tabPrescriptions);

    comboPrescAppointment = new QComboBox(this);
    txtPrescCode = new QLineEdit(this);
    txtPrescCode->setPlaceholderText("مثلاً: REC-1024");

    txtMedicineName = new QLineEdit(this);
    txtDosage = new QLineEdit(this);
    txtDosage->setPlaceholderText("مثلاً: هر 8 ساعت یک عدد");
    txtQuantity = new QLineEdit(this);

    btnSavePrescription = new QPushButton("ثبت نسخه الکترونیک و اقلام", this);

    prescLayout->addWidget(new QLabel("<h3>[ سربرگ نسخه ]</h3>"));
    prescLayout->addWidget(new QLabel("انتخاب نوبت بیمار (کد نوبت - بیمار):"));
    prescLayout->addWidget(comboPrescAppointment);
    prescLayout->addWidget(new QLabel("کد رهگیری نسخه:"));
    prescLayout->addWidget(txtPrescCode);

    prescLayout->addWidget(new QLabel("<hr><h3>[ اقلام نسخه (دارو) ]</h3>"));
    prescLayout->addWidget(new QLabel("نام دارو:"));
    prescLayout->addWidget(txtMedicineName);
    prescLayout->addWidget(new QLabel("دستور مصرف (Dosage):"));
    prescLayout->addWidget(txtDosage);
    prescLayout->addWidget(new QLabel("تعداد (Quantity):"));
    prescLayout->addWidget(txtQuantity);
    prescLayout->addWidget(btnSavePrescription);

    // اتصال دکمه به اسلات
    connect(btnSavePrescription, &QPushButton::clicked, this, &MainWindow::handleCreatePrescription);

    // لود کردن نوبت‌ها در کمبوباکس نسخه (نمایش نوبت‌هایی که ثبت شده‌اند)
    QSqlQuery qApps("SELECT A.AppointmentID, P.FirstName + ' ' + P.LastName FROM Appointments A JOIN Patients P ON A.PatientID = P.PatientID");
    while (qApps.next()) {
        QString displayText = "نوبت " + qApps.value(0).toString() + " - " + qApps.value(1).toString();
        comboPrescAppointment->addItem(displayText, qApps.value(0).toInt());
    }

    setCentralWidget(tabWidget);

    // 5. Connect button to the slot explicitly
    connect(btnRegister, &QPushButton::clicked, this, &MainWindow::handleRegister);

    // ۶. لود کردن نام و ID بخش‌ها در کمبوباکس‌ها
    QSqlQuery query("SELECT DepartmentID, DepartmentName FROM Departments");
    while (query.next()) {
        QString id = query.value(0).toString();
        QString name = query.value(1).toString();

        comboDepartments->addItem(name,id);
        comboDocDepartment->addItem(name,id);
    }
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::handleRegister()
{
    QString nationalCode = txtNationalCode->text().trimmed();
    QString firstName = firstNameEdit->text().trimmed();
    QString lastName = lastNameEdit->text().trimmed();
    QString birthDate = dateBirth->date().toString("yyyy-MM-dd");
    QString gender = comboGender->currentText();
    QString phoneNumber = txtPhoneNumber->text().trimmed();

    if (nationalCode.isEmpty() || firstName.isEmpty() || lastName.isEmpty()) {
        QMessageBox::warning(this, "Validation Error", "Please fill in all mandatory fields.");
        return;
    }

    QSqlQuery query;
    query.prepare("INSERT INTO Patients (NationalCode, FirstName, LastName, BirthDate, Gender, PhoneNumber) "
                  "VALUES (:natCode, :fName, :lName, :bDate, :gender, :phone)");

    query.bindValue(":natCode", nationalCode);
    query.bindValue(":fName", firstName);
    query.bindValue(":lName", lastName);
    query.bindValue(":bDate", birthDate);
    query.bindValue(":gender", gender);
    query.bindValue(":phone", phoneNumber.isEmpty() ? QVariant(QMetaType::fromType<QString>()) : phoneNumber);

    if (query.exec()) {
        QMessageBox::information(this, "Success", "Patient record saved successfully.");
        txtNationalCode->clear();
        firstNameEdit->clear();
        lastNameEdit->clear();
        txtPhoneNumber->clear();
    } else {
        QMessageBox::critical(this, "Database Write Error",
                              "Could not save patient data:\n" + query.lastError().text());
    }
}

void MainWindow::handleRegisterDoctor()
{
    QString firstName = txtDocFirstName->text().trimmed();
    QString lastName = txtDocLastName->text().trimmed();
    QString specialty = txtSpecialty->text().trimmed();
    QString phone = txtDocPhone->text().trimmed();
    int deptId = comboDocDepartment->currentData().toInt();

    if (firstName.isEmpty() || lastName.isEmpty() || specialty.isEmpty()) {
        QMessageBox::warning(this, "Validation Error", "Please fill in Name, Last Name, and Specialty.");
        return;
    }

    QSqlQuery query;
    query.prepare("INSERT INTO Doctors (FirstName, LastName, Specialty, PhoneNumber, DepartmentID) "
                  "VALUES (:fName, :lName, :spec, :phone, :deptId)");

    query.bindValue(":fName", firstName);
    query.bindValue(":lName", lastName);
    query.bindValue(":spec", specialty);
    query.bindValue(":phone", phone.isEmpty() ? QVariant(QMetaType::fromType<QString>()) : phone);
    query.bindValue(":deptId", deptId);

    if (query.exec()) {
        QMessageBox::information(this, "Success", "Doctor record saved successfully ");
        txtDocFirstName->clear();
        txtDocLastName->clear();
        txtSpecialty->clear();
        txtDocPhone->clear();
    } else {
        QMessageBox::critical(this, "Database Error", "Could not save doctor data:\n" + query.lastError().text());
    }
}

// اسلات پزشک: افزودن نوبت خالی به دیتابیس
void MainWindow::handleCreateSlot()
{
    int docId = comboSlotDoctor->currentData().toInt();
    QString slotTime = txtNewSlotDateTime->text().trimmed();

    if (slotTime.isEmpty()) {
        QMessageBox::warning(this, "Error", "Please enter Date & Time.");
        return;
    }

    QSqlQuery query;
    query.prepare("INSERT INTO AvailableSlots (DoctorID, SlotDateTime, IsAvailable) VALUES (:dId, :sTime, 1)");
    query.bindValue(":dId", docId);
    query.bindValue(":sTime", slotTime);

    if (query.exec()) {
        QMessageBox::information(this, "Success", "Available slot added successfully!");
        txtNewSlotDateTime->clear();
        handleDoctorSelectionChanged();
    } else {
        QMessageBox::critical(this, "DB Error", query.lastError().text());
    }
}

// اسلات هوشمند: لود کردن اسلات‌های زمانی خالی مخصوص پزشک انتخاب‌شده
void MainWindow::handleDoctorSelectionChanged()
{
    comboAppSlots->clear();
    int docId = comboAppDoctor->currentData().toInt();

    QSqlQuery query;
    query.prepare("SELECT SlotID, SlotDateTime FROM AvailableSlots WHERE DoctorID = :dId AND IsAvailable = 1");
    query.bindValue(":dId", docId);
    if (query.exec()) {
        while (query.next()) {
            comboAppSlots->addItem(query.value(1).toString(), query.value(0).toInt());
        }
    }
}

// اسلات بیمار: رزرو نوبت و تغییر وضعیت آن در دیتابیس به ۰ (غیرقابل انتخاب مجدد)
void MainWindow::handleRegisterAppointment()
{
    int patientId = comboAppPatient->currentData().toInt();
    int doctorId = comboAppDoctor->currentData().toInt();
    int slotId = comboAppSlots->currentData().toInt();
    QString selectedTime = comboAppSlots->currentText();

    if (comboAppSlots->currentIndex() == -1) {
        QMessageBox::warning(this, "Error", "No available slot selected!");
        return;
    }

    QSqlQuery query;
    query.prepare("INSERT INTO Appointments (PatientID, DoctorID, AppointmentDate) VALUES (:pId, :dId, :aDate)");
    query.bindValue(":pId", patientId);
    query.bindValue(":dId", doctorId);
    query.bindValue(":aDate", selectedTime);

    if (query.exec()) {
        QSqlQuery updateQuery;
        updateQuery.prepare("UPDATE AvailableSlots SET IsAvailable = 0 WHERE SlotID = :sId");
        updateQuery.bindValue(":sId", slotId);
        updateQuery.exec();

        QMessageBox::information(this, "Success", "Appointment booked successfully! This slot is now reserved.");
        handleDoctorSelectionChanged();
    } else {
        QMessageBox::critical(this, "DB Error", query.lastError().text());
    }
}

void MainWindow::handleCreatePrescription()
{
    int appointmentId = comboPrescAppointment->currentData().toInt();
    QString prescCode = txtPrescCode->text().trimmed();
    QString medName = txtMedicineName->text().trimmed();
    QString dosage = txtDosage->text().trimmed();
    int qty = txtQuantity->text().toInt();

    // اعتبار سنجی فیلدهای اجباری بر اساس ER
    if (prescCode.isEmpty() || medName.isEmpty() || dosage.isEmpty() || qty <= 0) {
        QMessageBox::warning(this, "Validation Error", "لطفاً تمام فیلدهای نسخه و اقلام دارو را به درستی پر کنید.");
        return;
    }

    QSqlQuery query;

    // مرحله اول: ثبت سربرگ نسخه در جدول Prescriptions
    query.prepare("INSERT INTO Prescriptions (AppointmentID, PrescriptionCode) VALUES (:appId, :code)");
    query.bindValue(":appId", appointmentId);
    query.bindValue(":code", prescCode);

    if (query.exec()) {
        // پیدا کردن ID نسخه‌ای که همین الان ثبت شد (Scope_Identity) برای ثبت اقلام آن
        QSqlQuery idQuery("SELECT @@IDENTITY");
        int lastPrescriptionId = 0;
        if (idQuery.next()) {
            lastPrescriptionId = idQuery.value(0).toInt();
        }

        if (lastPrescriptionId > 0) {
            // مرحله دوم: ثبت قلم دارو در جدول PrescriptionItems با استفاده از کلید خارجی نسخه
            QSqlQuery itemQuery;
            itemQuery.prepare("INSERT INTO PrescriptionItems (PrescriptionID, MedicineName, Dosage, Quantity) "
                              "VALUES (:pId, :med, :dose, :qty)");
            itemQuery.bindValue(":pId", lastPrescriptionId);
            itemQuery.bindValue(":med", medName);
            itemQuery.bindValue(":dose", dosage);
            itemQuery.bindValue(":qty", qty);

            if (itemQuery.exec()) {
                QMessageBox::information(this, "Success", "نسخه الکترونیک و اقلام دارو با موفقیت بر اساس مدل ER ثبت شد!");
                txtPrescCode->clear();
                txtMedicineName->clear();
                txtDosage->clear();
                txtQuantity->clear();
            } else {
                QMessageBox::critical(this, "Error", "سربرگ نسخه ثبت شد اما ثبت اقلام دارو خطا داد:\n" + itemQuery.lastError().text());
            }
        }
    } else {
        QMessageBox::critical(this, "Database Error", "خطا در ثبت سربرگ نسخه:\n" + query.lastError().text());
    }
}


