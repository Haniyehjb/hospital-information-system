#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QLineEdit>
#include <QComboBox>
#include <QDateEdit>
#include <QPushButton>
#include <QLabel>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void handleRegister();               // ثبت بیمار
    void handleRegisterDoctor();         // ثبت پزشک
    void handleCreateSlot();             // پنل پزشک: افزودن زمان خالی جدید
    void handleDoctorSelectionChanged(); // سیستم هوشمند: تغییر نوبت‌ها بر اساس پزشک انتخابی
    void handleRegisterAppointment();    // پنل بیمار: رزرو نوبت خالی
    void handleCreatePrescription();

private:
    Ui::MainWindow *ui;

    // المان‌های تب ثبت بیمار
    QLineEdit *txtNationalCode;
    QLineEdit *firstNameEdit;
    QLineEdit *lastNameEdit;
    QDateEdit *dateBirth;
    QComboBox *comboGender;
    QLineEdit *txtPhoneNumber;
    QComboBox *comboDepartments;
    QPushButton *btnRegister;

    // المان‌های تب ثبت پزشک
    QLineEdit *txtDocFirstName;
    QLineEdit *txtDocLastName;
    QLineEdit *txtSpecialty;
    QLineEdit *txtDocPhone;
    QComboBox *comboDocDepartment;
    QPushButton *btnRegisterDoctor;

    // المان‌های تب مدیریت هوشمند نوبت‌دهی (پزشک و بیمار)
    QComboBox *comboSlotDoctor;
    QLineEdit *txtNewSlotDateTime;
    QPushButton *btnCreateSlot;

    QComboBox *comboAppPatient;
    QComboBox *comboAppDoctor;
    QComboBox *comboAppSlots;            // زمان‌ها به صورت گزینه‌ای (کمبوباکس) لود می‌شوند
    QPushButton *btnRegisterAppointment;

    // المان‌های تب نسخه الکترونیک
    QComboBox *comboPrescAppointment;
    QLineEdit *txtPrescCode;
    QLineEdit *txtMedicineName;
    QLineEdit *txtDosage;
    QLineEdit *txtQuantity;
    QPushButton *btnSavePrescription;



};
#endif // MAINWINDOW_H
