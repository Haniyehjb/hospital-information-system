#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QSqlQuery>
#include <QSqlError>
#include <QMessageBox>
#include <QVariant>
#include <QVBoxLayout>
#include <QTabWidget>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    // 1. Create Tabs programmatically
    QTabWidget *tabWidget = new QTabWidget(this);
    QWidget *tabRegister = new QWidget();
    QWidget *tabDepartments = new QWidget();

    tabWidget->addTab(tabRegister, "Register Patient");
    tabWidget->addTab(tabDepartments, "Departments");

    QVBoxLayout *registerLayout = new QVBoxLayout(tabRegister);

    // 2. Initialize UI Elements
    txtNationalCode = new QLineEdit(this);
    firstNameEdit = new QLineEdit(this);
    lastNameEdit = new QLineEdit(this);

    dateBirth = new QDateEdit(this);
    dateBirth->setCalendarPopup(true);

    comboGender = new QComboBox(this);
    comboGender->addItem("Male");
    comboGender->addItem("Female");

    txtPhoneNumber = new QLineEdit(this);
    btnRegister = new QPushButton("Register Patient", this);

    // 3. Add Elements to Layout
    registerLayout->addWidget(new QLabel("National Code:"));
    registerLayout->addWidget(txtNationalCode);
    registerLayout->addWidget(new QLabel("First Name:"));
    registerLayout->addWidget(firstNameEdit);
    registerLayout->addWidget(new QLabel("Last Name:"));
    registerLayout->addWidget(lastNameEdit);
    registerLayout->addWidget(new QLabel("Birth Date:"));
    registerLayout->addWidget(dateBirth);
    registerLayout->addWidget(new QLabel("Gender:"));
    registerLayout->addWidget(comboGender);
    registerLayout->addWidget(new QLabel("Phone Number:"));
    registerLayout->addWidget(txtPhoneNumber);
    registerLayout->addWidget(btnRegister);

    // 4. Setup Department Tab
    QVBoxLayout *deptLayout = new QVBoxLayout(tabDepartments);
    comboDepartments = new QComboBox(this);
    deptLayout->addWidget(new QLabel("Select Department:"));
    deptLayout->addWidget(comboDepartments);

    setCentralWidget(tabWidget);

    // 5. Connect button to the slot explicitly
    connect(btnRegister, &QPushButton::clicked, this, &MainWindow::handleRegister);

    // 6. Fetch department names from SQL Server
    QSqlQuery query("SELECT DepartmentName FROM Departments");
    while (query.next()) {
        comboDepartments->addItem(query.value(0).toString());
    }
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::handleRegister()
{
    QString nationalCode = txtNationalCode->text().trimmed();
    QString firstName = firstNameEdit->text().trimmed();
    QString lastName = lastNameEdit->text().trimmed();
    QString birthDate = dateBirth->date().toString("yyyy-MM-dd");
    QString gender = comboGender->currentText();
    QString phoneNumber = txtPhoneNumber->text().trimmed();

    if (nationalCode.isEmpty() || firstName.isEmpty() || lastName.isEmpty()) {
        QMessageBox::warning(this, "Validation Error", "Please fill in all mandatory fields.");
        return;
    }

    QSqlQuery query;
    query.prepare("INSERT INTO Patients (NationalCode, FirstName, LastName, BirthDate, Gender, PhoneNumber) "
                  "VALUES (:natCode, :fName, :lName, :bDate, :gender, :phone)");

    query.bindValue(":natCode", nationalCode);
    query.bindValue(":fName", firstName);
    query.bindValue(":lName", lastName);
    query.bindValue(":bDate", birthDate);
    query.bindValue(":gender", gender);
    query.bindValue(":phone", phoneNumber.isEmpty() ? QVariant(QMetaType::fromType<QString>()) : phoneNumber);

    if (query.exec()) {
        QMessageBox::information(this, "Success", "Patient record saved successfully.");
        txtNationalCode->clear();
        firstNameEdit->clear();
        lastNameEdit->clear();
        txtPhoneNumber->clear();
    } else {
        QMessageBox::critical(this, "Database Write Error",
                              "Could not save patient data:\n" + query.lastError().text());
    }
}
