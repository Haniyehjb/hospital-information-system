#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QLineEdit>
#include <QComboBox>
#include <QDateEdit>
#include <QPushButton>
#include <QLabel>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void handleRegister(); // Renamed to avoid AutoMoc conflicts

private:
    Ui::MainWindow *ui;

    QLineEdit *txtNationalCode;
    QLineEdit *firstNameEdit;
    QLineEdit *lastNameEdit;
    QDateEdit *dateBirth;
    QComboBox *comboGender;
    QLineEdit *txtPhoneNumber;
    QPushButton *btnRegister;
    QComboBox *comboDepartments;
};
#endif // MAINWINDOW_H
