#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QLineEdit>
#include <QComboBox>
#include <QDateEdit>
#include <QPushButton>
#include <QLabel>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void handleRegister(); // Renamed to avoid AutoMoc conflicts
    void handleRegisterDoctor();
    void handleRegisterAppointment();

private:
    Ui::MainWindow *ui;

    QLineEdit *txtNationalCode;
    QLineEdit *firstNameEdit;
    QLineEdit *lastNameEdit;
    QDateEdit *dateBirth;
    QComboBox *comboGender;
    QLineEdit *txtPhoneNumber;
    QPushButton *btnRegister;
    QComboBox *comboDepartments;
    // المان‌های جدید تب پزشک بر اساس نمودار ER شما
    QLineEdit *txtDocFirstName;
    QLineEdit *txtDocLastName;
    QLineEdit *txtSpecialty;
    QLineEdit *txtDocPhone;
    QComboBox *comboDocDepartment;
    QPushButton *btnRegisterDoctor;

    QLineEdit *txtAppointmentDate; // یا استفاده از QDateTimeEdit
    QComboBox *comboAppPatient;
    QComboBox *comboAppDoctor;
    QPushButton *btnRegisterAppointment;
};
#endif // MAINWINDOW_H
