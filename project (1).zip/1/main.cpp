#include "mainwindow.h"
#include <QApplication>
#include <QSqlDatabase>
#include <QSqlError>
#include <QMessageBox>

bool connectToHospitalDB() {
    QSqlDatabase db = QSqlDatabase::addDatabase("QODBC");

    QString connectionString = "DRIVER={SQL Server};"
                               "SERVER=localhost\\MSSQLSERVER2022;"
                               "DATABASE=Hospital_DB;"
                               "Trusted_Connection=Yes;";

    db.setDatabaseName(connectionString);

    if (!db.open()) {
        QMessageBox::critical(nullptr, "Database Error",
                              "Failed to connect to SQL Server:\n" + db.lastError().text());
        return false;
    }
    return true;
}

int main(int argc, char *argv[]) {
    QApplication a(argc, argv);

    if (!connectToHospitalDB()) {
        return -1;
    }

    MainWindow w;
    w.show();
    return a.exec();
}
