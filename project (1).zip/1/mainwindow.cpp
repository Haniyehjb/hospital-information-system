#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QSqlQuery>
#include <QSqlError>
#include <QMessageBox>
#include <QVariant>
#include <QVBoxLayout>
#include <QTabWidget>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    // 1. Create Tabs programmatically
    QTabWidget *tabWidget = new QTabWidget(this);
    QWidget *tabRegister = new QWidget();
    QWidget *tabDepartments = new QWidget();

    tabWidget->addTab(tabRegister, "Register Patient");
    tabWidget->addTab(tabDepartments, "Departments");

    QVBoxLayout *registerLayout = new QVBoxLayout(tabRegister);

    // 2. Initialize UI Elements
    txtNationalCode = new QLineEdit(this);
    firstNameEdit = new QLineEdit(this);
    lastNameEdit = new QLineEdit(this);

    dateBirth = new QDateEdit(this);
    dateBirth->setCalendarPopup(true);

    comboGender = new QComboBox(this);
    comboGender->addItem("Male");
    comboGender->addItem("Female");

    txtPhoneNumber = new QLineEdit(this);
    btnRegister = new QPushButton("Register Patient", this);

    // 3. Add Elements to Layout
    registerLayout->addWidget(new QLabel("National Code:"));
    registerLayout->addWidget(txtNationalCode);
    registerLayout->addWidget(new QLabel("First Name:"));
    registerLayout->addWidget(firstNameEdit);
    registerLayout->addWidget(new QLabel("Last Name:"));
    registerLayout->addWidget(lastNameEdit);
    registerLayout->addWidget(new QLabel("Birth Date:"));
    registerLayout->addWidget(dateBirth);
    registerLayout->addWidget(new QLabel("Gender:"));
    registerLayout->addWidget(comboGender);
    registerLayout->addWidget(new QLabel("Phone Number:"));
    registerLayout->addWidget(txtPhoneNumber);
    registerLayout->addWidget(btnRegister);

    // 4. Setup Department Tab
    QVBoxLayout *deptLayout = new QVBoxLayout(tabDepartments);
    comboDepartments = new QComboBox(this);
    deptLayout->addWidget(new QLabel("Select Department:"));
    deptLayout->addWidget(comboDepartments);

    // ساخت تب پزشکان بر اساس نمودار ER
    QWidget *tabDoctors = new QWidget();
    tabWidget->addTab(tabDoctors, "Register Doctor");

    QVBoxLayout *doctorsLayout = new QVBoxLayout(tabDoctors);

    txtDocFirstName = new QLineEdit(this);
    txtDocLastName = new QLineEdit(this);
    txtSpecialty = new QLineEdit(this);
    txtDocPhone = new QLineEdit(this);
    comboDocDepartment = new QComboBox(this);
    btnRegisterDoctor = new QPushButton("Register Doctor", this);

    doctorsLayout->addWidget(new QLabel("First Name (نام):"));
    doctorsLayout->addWidget(txtDocFirstName);
    doctorsLayout->addWidget(new QLabel("Last Name (نام خانوادگی):"));
    doctorsLayout->addWidget(txtDocLastName);
    doctorsLayout->addWidget(new QLabel("Specialty (تخصص):"));
    doctorsLayout->addWidget(txtSpecialty);
    doctorsLayout->addWidget(new QLabel("Phone Number (تلفن):"));
    doctorsLayout->addWidget(txtDocPhone);
    doctorsLayout->addWidget(new QLabel("Department (بخش):"));
    doctorsLayout->addWidget(comboDocDepartment);
    doctorsLayout->addWidget(btnRegisterDoctor);

    connect(btnRegisterDoctor, &QPushButton::clicked, this, &MainWindow::handleRegisterDoctor);

    // ---- ساخت تب نوبت دهی (بخش جدید بر اساس نمودار ER) ----
    QWidget *tabAppointments = new QWidget();
    tabWidget->addTab(tabAppointments, "Register Appointment");

    QVBoxLayout *appLayout = new QVBoxLayout(tabAppointments);

    comboAppPatient = new QComboBox(this);
    comboAppDoctor = new QComboBox(this);
    txtAppointmentDate = new QLineEdit(this);
    txtAppointmentDate->setPlaceholderText("YYYY-MM-DD HH:MM:SS");
    btnRegisterAppointment = new QPushButton("Register Appointment", this);

    appLayout->addWidget(new QLabel("Select Patient (انتخاب بیمار):"));
    appLayout->addWidget(comboAppPatient);
    appLayout->addWidget(new QLabel("Select Doctor (انتخاب پزشک):"));
    appLayout->addWidget(comboAppDoctor);
    appLayout->addWidget(new QLabel("Appointment Date/Time (تاریخ و ساعت):"));
    appLayout->addWidget(txtAppointmentDate);
    appLayout->addWidget(btnRegisterAppointment);

    // متصل کردن دکمه به تابع ثبت نوبت
    connect(btnRegisterAppointment, &QPushButton::clicked, this, &MainWindow::handleRegisterAppointment);

    // لود کردن بیماران در کمبوباکس نوبت‌دهی
    QSqlQuery qPatients("SELECT PatientID, FirstName + ' ' + LastName FROM Patients");
    while (qPatients.next()) {
        comboAppPatient->addItem(qPatients.value(1).toString(), qPatients.value(0).toInt());
    }

    // لود کردن پزشکان در کمبوباکس نوبت‌دهی
    QSqlQuery qDoctors("SELECT DoctorID, FirstName + ' ' + LastName FROM Doctors");
    while (qDoctors.next()) {
        comboAppDoctor->addItem(qDoctors.value(1).toString(), qDoctors.value(0).toInt());
    }

    setCentralWidget(tabWidget);

    // 5. Connect button to the slot explicitly
    connect(btnRegister, &QPushButton::clicked, this, &MainWindow::handleRegister);

    // ۶. لود کردن نام و ID بخش‌ها در کمبوباکس‌ها
    QSqlQuery query("SELECT DepartmentID, DepartmentName FROM Departments");
    while (query.next()) {
        QString id = query.value(0).toString();
        QString name = query.value(1).toString();

        comboDepartments->addItem(name, id);       // فرم بیمار دوستت
        comboDocDepartment->addItem(name, id);    // فرم پزشک شما
    }
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::handleRegister()
{
    QString nationalCode = txtNationalCode->text().trimmed();
    QString firstName = firstNameEdit->text().trimmed();
    QString lastName = lastNameEdit->text().trimmed();
    QString birthDate = dateBirth->date().toString("yyyy-MM-dd");
    QString gender = comboGender->currentText();
    QString phoneNumber = txtPhoneNumber->text().trimmed();

    if (nationalCode.isEmpty() || firstName.isEmpty() || lastName.isEmpty()) {
        QMessageBox::warning(this, "Validation Error", "Please fill in all mandatory fields.");
        return;
    }

    QSqlQuery query;
    query.prepare("INSERT INTO Patients (NationalCode, FirstName, LastName, BirthDate, Gender, PhoneNumber) "
                  "VALUES (:natCode, :fName, :lName, :bDate, :gender, :phone)");

    query.bindValue(":natCode", nationalCode);
    query.bindValue(":fName", firstName);
    query.bindValue(":lName", lastName);
    query.bindValue(":bDate", birthDate);
    query.bindValue(":gender", gender);
    query.bindValue(":phone", phoneNumber.isEmpty() ? QVariant(QMetaType::fromType<QString>()) : phoneNumber);

    if (query.exec()) {
        QMessageBox::information(this, "Success", "Patient record saved successfully.");
        txtNationalCode->clear();
        firstNameEdit->clear();
        lastNameEdit->clear();
        txtPhoneNumber->clear();
    } else {
        QMessageBox::critical(this, "Database Write Error",
                              "Could not save patient data:\n" + query.lastError().text());
    }
}

void MainWindow::handleRegisterDoctor()
{
    QString firstName = txtDocFirstName->text().trimmed();
    QString lastName = txtDocLastName->text().trimmed();
    QString specialty = txtSpecialty->text().trimmed();
    QString phone = txtDocPhone->text().trimmed();
    int deptId = comboDocDepartment->currentData().toInt();

    if (firstName.isEmpty() || lastName.isEmpty() || specialty.isEmpty()) {
        QMessageBox::warning(this, "Validation Error", "Please fill in Name, Last Name, and Specialty.");
        return;
    }

    QSqlQuery query;
    query.prepare("INSERT INTO Doctors (FirstName, LastName, Specialty, PhoneNumber, DepartmentID) "
                  "VALUES (:fName, :lName, :spec, :phone, :deptId)");

    query.bindValue(":fName", firstName);
    query.bindValue(":lName", lastName);
    query.bindValue(":spec", specialty);
    query.bindValue(":phone", phone.isEmpty() ? QVariant(QMetaType::fromType<QString>()) : phone);
    query.bindValue(":deptId", deptId);

    if (query.exec()) {
        QMessageBox::information(this, "Success", "Doctor record saved successfully ");
        txtDocFirstName->clear();
        txtDocLastName->clear();
        txtSpecialty->clear();
        txtDocPhone->clear();
    } else {
        QMessageBox::critical(this, "Database Error", "Could not save doctor data:\n" + query.lastError().text());
    }
}

void MainWindow::handleRegisterAppointment()
{
    int patientId = comboAppPatient->currentData().toInt();
    int doctorId = comboAppDoctor->currentData().toInt();
    QString appDate = txtAppointmentDate->text().trimmed();

    if (appDate.isEmpty()) {
        QMessageBox::warning(this, "Validation Error", "Please enter the appointment date and time.");
        return;
    }

    QSqlQuery query;
    query.prepare("INSERT INTO Appointments (PatientID, DoctorID, AppointmentDate) "
                  "VALUES (:pId, :dId, :aDate)");

    query.bindValue(":pId", patientId);
    query.bindValue(":dId", doctorId);
    query.bindValue(":aDate", appDate);

    if (query.exec()) {
        QMessageBox::information(this, "Success", "Appointment registered successfully ");
        txtAppointmentDate->clear();
    } else {
        QMessageBox::critical(this, "Database Error", "Could not register appointment:\n" + query.lastError().text());
    }
}

