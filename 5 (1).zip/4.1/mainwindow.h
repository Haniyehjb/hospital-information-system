#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QTableWidget>
#include <QPushButton>
#include <QLineEdit>
#include <QComboBox>
#include <QDateEdit>
#include <QLabel>
#include <QTabWidget>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QFormLayout>
#include <QSqlQuery>
#include <QMessageBox>
#include <QHeaderView>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(int roleIndex, QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void handleNewInpatientAdmission();
    void handleRegister();
    void handleDoctorSelectionChanged();
    void handleRegisterAppointment();
    void loadAdmissionHistory();
    void loadPatientAppointments(int patientId);

    // Existing slots
    void handleCreateSlot();
    void handleCreatePrescription();
    void onRegisterLabTest();
    void onRegisterBed();

    void showPatientAdmissionWindow();
    void showInpatientWindow();
    void showBillingWindow();
    void showWalkInAppWindow();
    void showMedicalRecordsWindow();

    // 🟢 New Slots for Appointment Management
    void handleSearchPatientAppointments();
    void handleDeleteAppointment();
    void handleRescheduleAppointment();


    void handleSearchMedicalRecords();



    void handleSearchMedicalRecordsDoc();  // جستجوی سوابق در پنل پزشک
    void handleSearchMedicalRecordsRec();  // جستجوی سوابق در پنل منشی
    void handleSaveMedicalRecord();        // ثبت سابقه جدید توسط پزشک

private:
    Ui::MainWindow *ui;
    QWidget *centralWidgetContainer;

    // 🟢 New UI Elements for Managing Appointments (Pure C++)
    QLineEdit *txtSearchPatientId;
    QTableWidget *tableAppointments;
    QPushButton *btnSearchAppointments;
    QPushButton *btnCancelAppointment;
    QPushButton *btnRescheduleAppointment;
    QLineEdit *txtBedNum;
    QLineEdit *txtBedDeptId;

    // Doctor Elements
    QLineEdit *txtNewSlotDateTime;
    QPushButton *btnCreateSlot;
    QLineEdit *txtPrescPatientId;
    QLineEdit *txtPrescDocId;
    QLineEdit *txtMedication;
    QLineEdit *txtDosage;
    QPushButton *btnCreatePresc;

    // Laboratory Elements
    QLineEdit *txtLabPatId;
    QLineEdit *txtLabDocId;
    QLineEdit *txtTestName;
    QLineEdit *txtLabResult;

    // IT Elements
    // (اگر متغیری از قبل اینجا داشتید باقی می‌ماند)

    // 🟢 متغیرهای گمشده که باعث ارور شده بودند (بدون UI اضافه شدند)
    QComboBox *comboAdmitPatient;
    QLineEdit *txtAdmitBedNum;
    QComboBox *comboAdmitStatus;
    QDateEdit *dateAdmitStart;

    QLineEdit *txtNationalCode;
    QLineEdit *firstNameEdit;
    QLineEdit *lastNameEdit;
    QDateEdit *dateBirth;
    QComboBox *comboGender;
    QLineEdit *txtPhoneNumber;

    QComboBox *comboAppSlots;
    QComboBox *comboAppDoctor;
    QComboBox *comboAppPatient;


    // 🟢 المان‌های جدید برای تب سوابق درمانی پزشک
    QLineEdit *txtSearchRecordPatientId;
    QPushButton *btnSearchRecords;
    QTableWidget *tableMedicalRecords;

    QLineEdit *txtRecordPatientId;
    QLineEdit *txtRecordDocId;
    QLineEdit *txtRecordDiagnosis;
    QLineEdit *txtRecordTreatment;
    QPushButton *btnSaveMedicalRecord;


    // 🟢 المان‌های بخش پزشک (مشاهده + ثبت)
    QLineEdit *txtSearchRecordPatientIdDoc;
    QPushButton *btnSearchRecordsDoc;
    QTableWidget *tableMedicalRecordsDoc;
    QLineEdit *txtRecordAppId;


    // 🟢 المان‌های بخش منشی (فقط مشاهده و خواندن)
    QLineEdit *txtSearchRecordPatientIdRec;
    QPushButton *btnSearchRecordsRec;
    QTableWidget *tableMedicalRecordsRec;
};

#endif // MAINWINDOW_H
