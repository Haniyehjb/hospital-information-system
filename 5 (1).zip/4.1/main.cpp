#include "mainwindow.h"
#include <QApplication>
#include <QSqlDatabase>
#include <QSqlError>
#include "welcome.h"
#include <QMessageBox>

bool connectToHospitalDB() {
    QSqlDatabase db = QSqlDatabase::addDatabase("QODBC");

    // 🔴 اصلاح شد: نام سرور به نام SQLEXPRESS سیستم شما تغییر یافت
    QString connectionString = "DRIVER={SQL Server};"
                               "SERVER=localhost\\MSSQLSERVER2022;"
                               "DATABASE=Hospital_DB;"
                               "Trusted_Connection=Yes;";

    db.setDatabaseName(connectionString);

    if (!db.open()) {
        QMessageBox::critical(nullptr, "Database Error",
                              "Failed to connect to SQL Server:\n" + db.lastError().text());
        return false;
    }
    return true;
}

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

    // تلاش برای اتصال به پایگاه داده سیستم شما
    if (!connectToHospitalDB()) {
        return -1;
    }

    Welcome portal;
    if (portal.exec() == QDialog::Accepted) {
        int userRole = portal.getFinalRoleIndex();

        // باز شدن داشبورد اصلی برنامه با سطح دسترسی نقش کاربر
        MainWindow w(userRole);
        w.show();

        return a.exec();
    }

    return 0;
}
