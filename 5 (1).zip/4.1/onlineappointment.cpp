#include "onlineappointment.h"
#include <QVariant>
#include <QDebug>

OnlineAppointment::OnlineAppointment(QWidget *parent)
    : QDialog(parent), selectedSlotId(-1), currentPatientId(-1)
{
    setWindowTitle("Online Appointment Booking System");
    setMinimumSize(450, 550);

    setStyleSheet(
        "QDialog { background-color: #f8fafc; }"
        "QLabel { font-weight: bold; color: #334155; font-size: 13px; }"
        "QLineEdit { padding: 6px; border: 1px solid #cbd5e1; border-radius: 4px; background-color: #ffffff; color: #1e293b; }"
        "QComboBox { padding: 6px; border: 1px solid #cbd5e1; border-radius: 4px; background-color: #ffffff; color: #1e293b; }"
        "QComboBox QAbstractItemView { background-color: #ffffff; color: #1e293b; selection-background-color: #3b82f6; selection-color: white; }"
        "QPushButton:disabled { background-color: #cbd5e1; color: #94a3b8; border: 1px solid #cbd5e1; }"
        "QPushButton:enabled { background-color: #10b981; color: white; border-radius: 4px; font-weight: bold; padding: 6px; }"
        "QPushButton:enabled:hover { background-color: #059669; }"
        );

    QVBoxLayout *mainLayout = new QVBoxLayout(this);
    stackedWidget = new QStackedWidget(this);

    // ==================== PAGE 1: AUTHENTICATION ====================
    pageAuth = new QWidget(this);
    QVBoxLayout *layoutAuth = new QVBoxLayout(pageAuth);
    layoutAuth->setSpacing(12);

    lblNationalCode = new QLabel("Enter Patient National Code (10 Digits):", this);
    txtNationalCode = new QLineEdit(this);
    txtNationalCode->setPlaceholderText("e.g. 0012345678");
    QPushButton *btnCheck = new QPushButton("Check & Continue", this);

    layoutAuth->addWidget(lblNationalCode);
    layoutAuth->addWidget(txtNationalCode);
    layoutAuth->addWidget(btnCheck);
    layoutAuth->addStretch();

    // ==================== PAGE 2: REGISTRATION ====================
    pageRegister = new QWidget(this);
    QFormLayout *layoutReg = new QFormLayout(pageRegister);
    layoutReg->setSpacing(12);

    txtFirstName = new QLineEdit(this);
    txtLastName = new QLineEdit(this);
    txtPhoneNumber = new QLineEdit(this);

    dateBirth = new QDateEdit(this);
    dateBirth->setCalendarPopup(true);
    dateBirth->setDate(QDate::currentDate().addYears(-20));

    comboGender = new QComboBox(this);
    comboGender->addItems({"Male", "Female"});

    QPushButton *btnRegister = new QPushButton("Register & Continue", this);

    layoutReg->addRow("First Name:", txtFirstName);
    layoutReg->addRow("Last Name:", txtLastName);
    layoutReg->addRow("Phone Number:", txtPhoneNumber);
    layoutReg->addRow("Birth Date:", dateBirth);
    layoutReg->addRow("Gender:", comboGender);
    layoutReg->addRow(btnRegister);

    // ==================== PAGE 3: BOOKING ====================
    pageBooking = new QWidget(this);
    QVBoxLayout *layoutBooking = new QVBoxLayout(pageBooking);
    layoutBooking->setSpacing(12);

    lblSpecialty = new QLabel("Select Specialty:", this);
    comboSpecialty = new QComboBox(this);
    lblDoctor = new QLabel("Select Doctor:", this);
    comboDoctor = new QComboBox(this);
    lblDate = new QLabel("Select Available Date:", this);
    comboDate = new QComboBox(this);

    lblSlots = new QLabel("Available Time Slots (15 Mins Intervals):", this);
    slotsContainer = new QWidget(this);
    slotsLayout = new QGridLayout(slotsContainer);
    lblSlots->hide();
    slotsContainer->hide();

    btnConfirm = new QPushButton("Confirm Booking", this);
    btnConfirm->setEnabled(false);

    layoutBooking->addWidget(lblSpecialty);
    layoutBooking->addWidget(comboSpecialty);
    layoutBooking->addWidget(lblDoctor);
    layoutBooking->addWidget(comboDoctor);
    layoutBooking->addWidget(lblDate);
    layoutBooking->addWidget(comboDate);
    layoutBooking->addWidget(lblSlots);
    layoutBooking->addWidget(slotsContainer);
    layoutBooking->addWidget(btnConfirm);

    // افزودن صفحات به Stacked Widget
    stackedWidget->addWidget(pageAuth);     // Index 0
    stackedWidget->addWidget(pageRegister); // Index 1
    stackedWidget->addWidget(pageBooking);  // Index 2

    mainLayout->addWidget(stackedWidget);

    // اتصال سیگنال‌ها و اسلات‌ها
    connect(btnCheck, &QPushButton::clicked, this, &OnlineAppointment::onCheckClicked);
    connect(btnRegister, &QPushButton::clicked, this, &OnlineAppointment::onRegisterAndContinueClicked);
    connect(btnConfirm, &QPushButton::clicked, this, &OnlineAppointment::onSlotClicked);

    connect(comboSpecialty, &QComboBox::currentIndexChanged, this, &OnlineAppointment::onSpecialtyChanged);
    connect(comboDoctor, &QComboBox::currentIndexChanged, this, &OnlineAppointment::onDoctorChanged);
    connect(comboDate, &QComboBox::currentIndexChanged, this, &OnlineAppointment::onDateChanged);

    loadSpecialties();
}

OnlineAppointment::~OnlineAppointment() {}

void OnlineAppointment::onCheckClicked() {
    QString nc = txtNationalCode->text().trimmed();

    if (nc.isEmpty() || nc.length() != 10) {
        QMessageBox::warning(this, "Input Error", "Please enter a valid 10-digit National Code.");
        return;
    }

    QSqlQuery query;
    query.prepare("SELECT PatientID FROM Patients WHERE NationalCode = :nc");
    query.bindValue(":nc", nc);

    if (query.exec() && query.next()) {
        this->currentPatientId = query.value(0).toInt();
        stackedWidget->setCurrentWidget(pageBooking);
    } else {
        stackedWidget->setCurrentWidget(pageRegister);
    }
}

void OnlineAppointment::onRegisterAndContinueClicked() {
    QString nc = txtNationalCode->text().trimmed();
    QString fn = txtFirstName->text().trimmed();
    QString ln = txtLastName->text().trimmed();
    QString ph = txtPhoneNumber->text().trimmed();

    if (fn.isEmpty() || ln.isEmpty()) {
        QMessageBox::warning(this, "Input Error", "Please complete First Name and Last Name fields.");
        return;
    }

    QSqlQuery insertPat;
    insertPat.prepare("INSERT INTO Patients (NationalCode, FirstName, LastName, BirthDate, Gender, PhoneNumber) "
                      "VALUES (:nc, :fn, :ln, :dob, :g, :ph)");
    insertPat.bindValue(":nc", nc);
    insertPat.bindValue(":fn", fn);
    insertPat.bindValue(":ln", ln);
    insertPat.bindValue(":dob", dateBirth->date().toString("yyyy-MM-dd"));
    insertPat.bindValue(":g", comboGender->currentText());
    insertPat.bindValue(":ph", ph);

    if (insertPat.exec()) {
        this->currentPatientId = insertPat.lastInsertId().toInt();
        QMessageBox::information(this, "Success", "Registration completed successfully.");
        stackedWidget->setCurrentWidget(pageBooking);
    } else {
        QMessageBox::critical(this, "Database Error", "Failed to register patient: " + insertPat.lastError().text());
    }
}

void OnlineAppointment::loadSpecialties() {
    comboSpecialty->blockSignals(true);
    comboSpecialty->clear();
    specialtyIds.clear();

    QSqlQuery query("SELECT SpecialtyID, SpecialtyName FROM Specialties");
    while (query.next()) {
        specialtyIds.append(query.value(0).toInt());
        comboSpecialty->addItem(query.value(1).toString());
    }
    comboSpecialty->setCurrentIndex(-1);
    comboSpecialty->blockSignals(false);
}

void OnlineAppointment::onSpecialtyChanged(int index) {
    if (index < 0 || index >= specialtyIds.size()) {
        comboDoctor->clear();
        comboDate->clear();
        lblSlots->hide();
        slotsContainer->hide();
        return;
    }
    loadDoctors(specialtyIds[index]);
}

void OnlineAppointment::loadDoctors(int specialtyId) {
    lblSlots->hide();
    slotsContainer->hide();
    comboDoctor->blockSignals(true);
    comboDoctor->clear();
    doctorIds.clear();

    QSqlQuery query;
    query.prepare("SELECT DoctorID, FirstName + ' ' + LastName FROM Doctors WHERE SpecialtyID = :specId");
    query.bindValue(":specId", specialtyId);

    if (query.exec()) {
        while (query.next()) {
            doctorIds.append(query.value(0).toInt());
            comboDoctor->addItem(query.value(1).toString());
        }
    }
    comboDoctor->setCurrentIndex(-1);
    comboDoctor->blockSignals(false);

    if (comboDoctor->count() == 0) {
        comboDate->clear();
        QLayoutItem *item;
        while ((item = slotsLayout->takeAt(0)) != nullptr) { delete item->widget(); delete item; }
        btnConfirm->setEnabled(false);
    }
}

void OnlineAppointment::onDoctorChanged(int index) {
    if (index < 0 || index >= doctorIds.size()) {
        comboDate->clear();
        lblSlots->hide();
        slotsContainer->hide();
        return;
    }
    loadAvailableDates(doctorIds[index]);
}

void OnlineAppointment::loadAvailableDates(int doctorId) {
    lblSlots->hide();
    slotsContainer->hide();
    comboDate->blockSignals(true);
    comboDate->clear();

    QSqlQuery query;
    query.prepare("SELECT DISTINCT CAST(SlotDateTime AS DATE) FROM OnlineAppointments "
                  "WHERE DoctorID = :docId AND SlotDateTime >= GETDATE() ORDER BY CAST(SlotDateTime AS DATE)");
    query.bindValue(":docId", doctorId);

    if (query.exec()) {
        while (query.next()) {
            QString dateStr = query.value(0).toDate().toString("yyyy-MM-dd");
            comboDate->addItem(dateStr);
        }
    }
    comboDate->setCurrentIndex(-1);
    comboDate->blockSignals(false);

    if (comboDate->count() == 0) {
        QLayoutItem *item;
        while ((item = slotsLayout->takeAt(0)) != nullptr) { delete item->widget(); delete item; }
        btnConfirm->setEnabled(false);
    }
}

void OnlineAppointment::onDateChanged(int index) {
    if (index < 0 || comboDoctor->currentIndex() < 0) {
        lblSlots->hide();
        slotsContainer->hide();
        return;
    }
    int doctorId = doctorIds[comboDoctor->currentIndex()];
    QString dateStr = comboDate->currentText();
    loadSlots(doctorId, dateStr);
}

void OnlineAppointment::loadSlots(int doctorId, const QString &dateStr) {
    QLayoutItem *child;
    while ((child = slotsLayout->takeAt(0)) != nullptr) {
        if(child->widget()) delete child->widget();
        delete child;
    }
    selectedSlotId = -1;
    btnConfirm->setEnabled(false);

    QSqlQuery query;
    query.prepare("SELECT AppointmentID, SlotDateTime, IsBooked FROM OnlineAppointments "
                  "WHERE DoctorID = :docId AND CAST(SlotDateTime AS DATE) = :date "
                  "ORDER BY SlotDateTime");
    query.bindValue(":docId", doctorId);
    query.bindValue(":date", dateStr);

    if (query.exec()) {
        int row = 0;
        int col = 0;
        while (query.next()) {
            int appId = query.value(0).toInt();
            QDateTime slotTime = query.value(1).toDateTime();
            bool isBooked = query.value(2).toBool();

            QString timeStr = slotTime.time().toString("HH:mm");
            QPushButton *slotBtn = new QPushButton(timeStr, this);
            slotBtn->setCheckable(true);

            slotBtn->setStyleSheet(
                "QPushButton { background-color: #e2e8f0; color: #1e293b; border: 1px solid #cbd5e1; padding: 8px; border-radius: 4px; }"
                "QPushButton:checked { background-color: #3b82f6; color: white; font-weight: bold; }"
                "QPushButton:disabled { background-color: #cbd5e1; color: #94a3b8; border: 1px solid #cbd5e1; }"
                );

            if (isBooked) {
                slotBtn->setEnabled(false);
                slotBtn->setText(timeStr + "\n(Full)");
            } else {
                slotBtn->setProperty("AppointmentID", appId);
                connect(slotBtn, &QPushButton::clicked, this, [this, slotBtn, appId]() {
                    for (int i = 0; i < slotsLayout->count(); ++i) {
                        QPushButton *b = qobject_cast<QPushButton*>(slotsLayout->itemAt(i)->widget());
                        if (b && b != slotBtn) b->setChecked(false);
                    }
                    if (slotBtn->isChecked()) {
                        selectedSlotId = appId;
                        btnConfirm->setEnabled(true);
                    } else {
                        selectedSlotId = -1;
                        btnConfirm->setEnabled(false);
                    }
                });
            }

            slotsLayout->addWidget(slotBtn, row, col);
            col++;
            if (col >= 4) { col = 0; row++; }
        }

        if (slotsLayout->count() > 0) {
            lblSlots->show();
            slotsContainer->show();
        } else {
            lblSlots->hide();
            slotsContainer->hide();
        }
    }
}

void OnlineAppointment::onSlotClicked() {
    if (selectedSlotId == -1 || currentPatientId == -1) {
        QMessageBox::warning(this, "Selection Error", "Please select a time slot and ensure patient ID is valid.");
        return;
    }

    QSqlQuery updateApp;
    updateApp.prepare("UPDATE OnlineAppointments SET PatientID = :patId, IsBooked = 1 WHERE AppointmentID = :appId");
    updateApp.bindValue(":patId", currentPatientId);
    updateApp.bindValue(":appId", selectedSlotId);

    if (updateApp.exec()) {
        QMessageBox::information(this, "Success", "Your appointment has been booked successfully.");
        this->accept();
    } else {
        QMessageBox::critical(this, "Booking Error", "Failed to book the appointment: " + updateApp.lastError().text());
    }
}
