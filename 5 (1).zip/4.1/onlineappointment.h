#ifndef ONLINEAPPOINTMENT_H
#define ONLINEAPPOINTMENT_H

#include <QDialog>
#include <QComboBox>
#include <QLineEdit>
#include <QPushButton>
#include <QVBoxLayout>
#include <QGridLayout>
#include <QFormLayout>
#include <QLabel>
#include <QSqlQuery>
#include <QSqlError>
#include <QMessageBox>
#include <QDateTime>
#include <QVector>
#include <QStackedWidget>
#include <QDateEdit>

class OnlineAppointment : public QDialog
{
    Q_OBJECT

public:
    explicit OnlineAppointment(QWidget *parent = nullptr);
    ~OnlineAppointment();

private slots:
    void onSpecialtyChanged(int index);
    void onDoctorChanged(int index);
    void onDateChanged(int index);
    void onSlotClicked();

    // توابع جدید مربوط به دکمه‌ها و مدیریت صفحات
    void onCheckClicked();
    void onRegisterAndContinueClicked();

private:
    void loadSpecialties();
    void loadDoctors(int specialtyId);
    void loadAvailableDates(int doctorId);
    void loadSlots(int doctorId, const QString &dateStr);

    // مدیریت صفحات
    QStackedWidget *stackedWidget;
    QWidget *pageAuth;
    QWidget *pageRegister;
    QWidget *pageBooking;

    // المان‌های صفحه اول (احراز هویت)
    QLabel *lblNationalCode;
    QLineEdit *txtNationalCode;

    // المان‌های صفحه دوم (ثبت‌نام بیمار جدید)
    QLineEdit *txtFirstName;
    QLineEdit *txtLastName;
    QLineEdit *txtPhoneNumber;
    QDateEdit *dateBirth;
    QComboBox *comboGender;

    // المان‌های صفحه سوم (نوبت‌دهی)
    QLabel *lblSpecialty;
    QComboBox *comboSpecialty;
    QLabel *lblDoctor;
    QComboBox *comboDoctor;
    QLabel *lblDate;
    QComboBox *comboDate;
    QLabel *lblSlots;
    QWidget *slotsContainer;
    QGridLayout *slotsLayout;
    QPushButton *btnConfirm;

    // متغیرهای داده‌ای
    QVector<int> specialtyIds;
    QVector<int> doctorIds;
    int selectedSlotId;
    int currentPatientId; // ذخیره شناسه بیمار جاری
};

#endif // ONLINEAPPOINTMENT_H
