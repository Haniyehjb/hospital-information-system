#include "mainwindow.h"
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QTabWidget>
#include <QFormLayout>
#include <QHeaderView>
#include <QLabel>
#include <QDateEdit>
#include <QMessageBox>
#include <QSqlError>
#include "onlineappointment.h"


MainWindow::MainWindow(int roleIndex, QWidget *parent)
    : QMainWindow(parent)
    , ui(nullptr)
    , centralWidgetContainer(nullptr)
{
    // ======================================================================
    // ۱. مقداردهی متغیرهای پویا (Pure C++) جهت جلوگیری از خطاهای اسکوپ و کرش
    // ======================================================================
    txtNationalCode = new QLineEdit(this);
    firstNameEdit = new QLineEdit(this);
    lastNameEdit = new QLineEdit(this);
    dateBirth = new QDateEdit(this);
    dateBirth->setCalendarPopup(true);
    comboGender = new QComboBox(this);
    comboGender->addItems({"Male", "Female"});
    txtPhoneNumber = new QLineEdit(this);

    comboAdmitPatient = new QComboBox(this);
    txtAdmitBedNum = new QLineEdit(this);
    comboAdmitStatus = new QComboBox(this);
    comboAdmitStatus->addItems({"Admitted", "Discharged", "Transferred"});
    dateAdmitStart = new QDateEdit(this);
    dateAdmitStart->setCalendarPopup(true);

    comboAppPatient = new QComboBox(this);
    comboAppDoctor = new QComboBox(this);
    comboAppSlots = new QComboBox(this);

    // ----------------------------------------------------------------------
    // نقش ۱: کارمند پذیرش (RECEPTIONIST ROLE)
    // ----------------------------------------------------------------------
    if (roleIndex == 1) {
        setWindowTitle("Hospital HIS - Receptionist Dashboard");
        setMinimumSize(600, 550);

        QTabWidget *receptionTabs = new QTabWidget(this);

        // ---- TAB 1: Main Menu ----
        QWidget *receptionWidget = new QWidget(this);
        receptionWidget->setStyleSheet("background-color: #f8fafc;");
        QVBoxLayout *mainMenuLayout = new QVBoxLayout(receptionWidget);

        QLabel *lblTitle = new QLabel("<h2>Reception Main Menu</h2>", receptionWidget);
        lblTitle->setAlignment(Qt::AlignCenter);
        mainMenuLayout->addWidget(lblTitle);

        QPushButton *btn1 = new QPushButton("➡️ Patient Admission", receptionWidget);
        QPushButton *btn2 = new QPushButton("🛌 Inpatient Bed Admission", receptionWidget);
        QPushButton *btn3 = new QPushButton("💰 Billing & Invoices", receptionWidget);
        QPushButton *btn4 = new QPushButton("📅 Walk-in Appointment", receptionWidget);
        QPushButton *btn5 = new QPushButton("👤 Patient Medical Records", receptionWidget);

        QString s = "QPushButton { background-color: #2563eb; color: white; font-weight: bold; padding: 10px; border-radius: 5px; }";
        btn1->setStyleSheet(s); btn2->setStyleSheet(s); btn3->setStyleSheet(s); btn4->setStyleSheet(s); btn5->setStyleSheet(s);

        mainMenuLayout->addWidget(btn1);
        mainMenuLayout->addWidget(btn2);
        mainMenuLayout->addWidget(btn3);
        mainMenuLayout->addWidget(btn4);
        mainMenuLayout->addWidget(btn5);
        mainMenuLayout->addStretch();

        connect(btn1, &QPushButton::clicked, this, &MainWindow::showPatientAdmissionWindow);
        connect(btn2, &QPushButton::clicked, this, &MainWindow::showInpatientWindow);
        connect(btn3, &QPushButton::clicked, this, &MainWindow::showBillingWindow);
        connect(btn4, &QPushButton::clicked, this, &MainWindow::showWalkInAppWindow);
        connect(btn5, &QPushButton::clicked, this, &MainWindow::showMedicalRecordsWindow);

        receptionTabs->addTab(receptionWidget, "Dashboard Actions");

        // ---- TAB 2: Manage Online Appointments ----
        QWidget *tabManageApp = new QWidget(this);
        QVBoxLayout *manageLayout = new QVBoxLayout(tabManageApp);

        QHBoxLayout *searchLayout = new QHBoxLayout();
        txtSearchPatientId = new QLineEdit(this);
        txtSearchPatientId->setPlaceholderText("Enter Patient ID to look up...");
        btnSearchAppointments = new QPushButton("Search Appointments", this);
        searchLayout->addWidget(new QLabel("Patient ID:"));
        searchLayout->addWidget(txtSearchPatientId);
        searchLayout->addWidget(btnSearchAppointments);
        manageLayout->addLayout(searchLayout);

        tableAppointments = new QTableWidget(this);
        tableAppointments->setColumnCount(3);
        tableAppointments->setHorizontalHeaderLabels({"Appointment ID", "Doctor Name", "Date & Time"});
        tableAppointments->setSelectionBehavior(QAbstractItemView::SelectRows);
        tableAppointments->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
        manageLayout->addWidget(tableAppointments);

        QHBoxLayout *actionLayout = new QHBoxLayout();
        btnCancelAppointment = new QPushButton("Cancel Selected Appointment", this);
        btnRescheduleAppointment = new QPushButton("Reschedule Selected Appointment", this);

        btnCancelAppointment->setStyleSheet("background-color: #ef4444; color: white; font-weight: bold; padding: 6px;");
        btnRescheduleAppointment->setStyleSheet("background-color: #f59e0b; color: white; font-weight: bold; padding: 6px;");

        actionLayout->addWidget(btnCancelAppointment);
        actionLayout->addWidget(btnRescheduleAppointment);
        manageLayout->addLayout(actionLayout);

        receptionTabs->addTab(tabManageApp, "Manage Appointments");

        connect(btnSearchAppointments, &QPushButton::clicked, this, &MainWindow::handleSearchPatientAppointments);
        connect(btnCancelAppointment, &QPushButton::clicked, this, &MainWindow::handleDeleteAppointment);
        connect(btnRescheduleAppointment, &QPushButton::clicked, this, &MainWindow::handleRescheduleAppointment);

        centralWidgetContainer = receptionTabs;
    }
    // ------------------------------------------------------------
    // نقش ۲: پزشک (DOCTOR ROLE)
    // ------------------------------------------------------------
    else if (roleIndex == 2) {
        setWindowTitle("Hospital HIS - Doctor Dashboard");
        QTabWidget *tabWidget = new QTabWidget(this);

        // ---- تب ۱: مدیریت اسلات‌های کاری ----
        QWidget *tabSlots = new QWidget();
        QVBoxLayout *slotsLayout = new QVBoxLayout(tabSlots);
        QFormLayout *slotsForm = new QFormLayout();
        txtNewSlotDateTime = new QLineEdit(this);
        txtNewSlotDateTime->setPlaceholderText("YYYY-MM-DD HH:MM");
        slotsForm->addRow("New Slot (DateTime):", txtNewSlotDateTime);
        btnCreateSlot = new QPushButton("Add Free Slot", this);
        slotsLayout->addLayout(slotsForm);
        slotsLayout->addWidget(btnCreateSlot);
        tabWidget->addTab(tabSlots, "Manage Work Slots");
        connect(btnCreateSlot, &QPushButton::clicked, this, &MainWindow::handleCreateSlot);

        // ---- تب ۲: نسخه نویسی دارو ----
        QWidget *tabPresc = new QWidget();
        QVBoxLayout *prescLayout = new QVBoxLayout(tabPresc);
        QFormLayout *prescForm = new QFormLayout();
        txtPrescPatientId = new QLineEdit(this);
        txtPrescDocId = new QLineEdit(this);
        txtMedication = new QLineEdit(this);
        txtDosage = new QLineEdit(this);
        prescForm->addRow("Patient ID:", txtPrescPatientId);
        prescForm->addRow("Doctor ID:", txtPrescDocId);
        prescForm->addRow("Medication Name:", txtMedication);
        prescForm->addRow("Dosage:", txtDosage);
        btnCreatePresc = new QPushButton("Issue Prescription", this);
        prescLayout->addLayout(prescForm);
        prescLayout->addWidget(btnCreatePresc);
        tabWidget->addTab(tabPresc, "Write Prescription");
        connect(btnCreatePresc, &QPushButton::clicked, this, &MainWindow::handleCreatePrescription);

        // ---- تب ۳: سوابق درمانی (مشاهده پزشکان + ثبت جدید) ----
        QWidget *tabMedicalRecords = new QWidget();
        QVBoxLayout *recordsLayout = new QVBoxLayout(tabMedicalRecords);

        // ۱. جستجوی سوابق ثبت شده قبلی توسط پزشکان دیگر
        QHBoxLayout *searchLayout = new QHBoxLayout();
        txtSearchRecordPatientIdDoc = new QLineEdit(this);
        txtSearchRecordPatientIdDoc->setPlaceholderText("Enter Patient ID to view history...");
        btnSearchRecordsDoc = new QPushButton("Search History", this);
        btnSearchRecordsDoc->setStyleSheet("background-color: #2563eb; color: white; font-weight: bold;");
        searchLayout->addWidget(new QLabel("Patient ID:"));
        searchLayout->addWidget(txtSearchRecordPatientIdDoc);
        searchLayout->addWidget(btnSearchRecordsDoc);
        recordsLayout->addLayout(searchLayout);

        // ۲. جدول نمایش سوابق بیمار برای پزشک
        tableMedicalRecordsDoc = new QTableWidget(this);
        tableMedicalRecordsDoc->setColumnCount(5);
        tableMedicalRecordsDoc->setHorizontalHeaderLabels({"Record ID", "App ID", "Doctor ID", "Diagnosis", "Treatment"});
        tableMedicalRecordsDoc->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
        recordsLayout->addWidget(tableMedicalRecordsDoc);

        // ۳. فرم ثبت سابقه درمانی جدید برای نوبت فعلی بیمار (مختص پزشک)
        QFormLayout *newRecordForm = new QFormLayout();
        newRecordForm->addRow(new QLabel("<h3>Record New Diagnosis & Treatment</h3>"));

        txtRecordAppId = new QLineEdit(this);
        txtRecordPatientId = new QLineEdit(this);
        txtRecordDocId = new QLineEdit(this);
        txtRecordDiagnosis = new QLineEdit(this);
        txtRecordTreatment = new QLineEdit(this);

        newRecordForm->addRow("Appointment ID (شماره نوبت) *:", txtRecordAppId);
        newRecordForm->addRow("Patient ID *:", txtRecordPatientId);
        newRecordForm->addRow("Doctor ID *:", txtRecordDocId);
        newRecordForm->addRow("Diagnosis (تشخیص) *:", txtRecordDiagnosis);
        newRecordForm->addRow("Treatment (درمان):", txtRecordTreatment);

        btnSaveMedicalRecord = new QPushButton("➕ Save Patient Medical Record", this);
        btnSaveMedicalRecord->setStyleSheet("background-color: #10b981; color: white; font-weight: bold; padding: 8px;");

        recordsLayout->addLayout(newRecordForm);
        recordsLayout->addWidget(btnSaveMedicalRecord);

        tabWidget->addTab(tabMedicalRecords, "Medical Records");

        // اتصال دکمه‌های پنل پزشک
        connect(btnSearchRecordsDoc, &QPushButton::clicked, this, &MainWindow::handleSearchMedicalRecordsDoc);
        connect(btnSaveMedicalRecord, &QPushButton::clicked, this, &MainWindow::handleSaveMedicalRecord);

        centralWidgetContainer = tabWidget;
    }
    // ------------------------------------------------------------
    // نقش ۳: آزمایشگاه (LABORATORY ROLE)
    // ------------------------------------------------------------
    else if (roleIndex == 3) {
        setWindowTitle("Hospital HIS - Laboratory Module");
        QTabWidget *tabWidget = new QTabWidget(this);

        QWidget *tabLab = new QWidget();
        QVBoxLayout *labLayout = new QVBoxLayout(tabLab);
        QFormLayout *labForm = new QFormLayout();

        txtLabPatId = new QLineEdit(this);
        txtLabDocId = new QLineEdit(this);
        txtTestName = new QLineEdit(this);
        txtLabResult = new QLineEdit(this);

        labForm->addRow("Patient ID:", txtLabPatId);
        labForm->addRow("Doctor ID:", txtLabDocId);
        labForm->addRow("Test Type/Name:", txtTestName);
        labForm->addRow("Result Description:", txtLabResult);

        QPushButton *btnLab = new QPushButton("Submit Lab Test Result", this);
        btnLab->setStyleSheet("background-color: #a855f7; color: white; font-weight: bold; padding: 8px;");
        labLayout->addLayout(labForm);
        labLayout->addWidget(btnLab);
        labLayout->addStretch();
        tabWidget->addTab(tabLab, "Laboratory Recording");
        connect(btnLab, &QPushButton::clicked, this, &MainWindow::onRegisterLabTest);

        centralWidgetContainer = tabWidget;
    }
    // ------------------------------------------------------------
    // نقش ۴: مدیر زیرساخت فناوری اطلاعات (IT ROLE)
    // ------------------------------------------------------------
    else {
        setWindowTitle("Hospital HIS - IT Infrastructure Admin");
        QTabWidget *tabWidget = new QTabWidget(this);

        QWidget *tabAdmin = new QWidget();
        QVBoxLayout *adminLayout = new QVBoxLayout(tabAdmin);
        QFormLayout *f = new QFormLayout();

        txtBedNum = new QLineEdit(this);
        txtBedDeptId = new QLineEdit(this);

        f->addRow("Bed Number:", txtBedNum);
        f->addRow("Department ID:", txtBedDeptId);

        QPushButton *b = new QPushButton("Register Hospital Bed", this);
        b->setStyleSheet("background-color: #475569; color: white; font-weight: bold; padding: 8px;");
        adminLayout->addLayout(f);
        adminLayout->addWidget(b);
        adminLayout->addStretch();
        tabWidget->addTab(tabAdmin, "Bed Infrastructure");
        connect(b, &QPushButton::clicked, this, &MainWindow::onRegisterBed);

        centralWidgetContainer = tabWidget;
    }

    if (centralWidgetContainer) {
        setCentralWidget(centralWidgetContainer);
    }
}

// ======================================================================
// ۲. پیاده‌سازی متدهای عملیاتی بخش‌های مختلف سیستم
// ======================================================================

void MainWindow::handleNewInpatientAdmission() {
    int patientId = comboAdmitPatient->currentData().toInt();
    QString bedNumStr = txtAdmitBedNum->text().trimmed();
    QString status = comboAdmitStatus->currentText();
    QString dateStr = dateAdmitStart->date().toString("yyyy-MM-dd");

    if (bedNumStr.isEmpty() || comboAdmitPatient->currentIndex() == -1) {
        QMessageBox::warning(this, "Validation Error", "Please fill all required fields.");
        return;
    }

    QSqlQuery query;
    query.prepare("INSERT INTO InpatientAdmissions (PatientID, BedNumber, AdmissionDate, Status) "
                  "VALUES (:pId, :bed, :date, :status)");
    query.bindValue(":pId", patientId);
    query.bindValue(":bed", bedNumStr.toInt());
    query.bindValue(":date", dateStr);
    query.bindValue(":status", status);

    if (query.exec()) {
        QMessageBox::information(this, "Success", "Admission registered successfully.");
        txtAdmitBedNum->clear();
        loadAdmissionHistory();
    } else {
        QMessageBox::critical(this, "Database Error", query.lastError().text());
    }
}

void MainWindow::handleRegister() {
    QSqlQuery query;
    query.prepare("INSERT INTO Patients (NationalCode, FirstName, LastName, BirthDate, Gender, PhoneNumber) "
                  "VALUES (:nc, :fn, :ln, :dob, :g, :phone)");
    query.bindValue(":nc", txtNationalCode->text());
    query.bindValue(":fn", firstNameEdit->text());
    query.bindValue(":ln", lastNameEdit->text());
    query.bindValue(":dob", dateBirth->date().toString("yyyy-MM-dd"));
    query.bindValue(":g", comboGender->currentText());
    query.bindValue(":phone", txtPhoneNumber->text());

    if (query.exec()) {
        QMessageBox::information(this, "Success", "Patient registered successfully.");
        txtNationalCode->clear();
        firstNameEdit->clear();
        lastNameEdit->clear();
        txtPhoneNumber->clear();
    } else {
        QMessageBox::critical(this, "Database Error", query.lastError().text());
    }
}

void MainWindow::handleDoctorSelectionChanged() {
    comboAppSlots->clear();
    int docId = comboAppDoctor->currentData().toInt();
    QSqlQuery q;
    q.prepare("SELECT SlotID, SlotDateTime FROM DoctorSlots WHERE DoctorID = :dId AND IsBooked = 0");
    q.bindValue(":dId", docId);
    if (q.exec()) {
        while (q.next()) {
            comboAppSlots->addItem(q.value(1).toString(), q.value(0).toInt());
        }
    }
}

void MainWindow::handleRegisterAppointment() {
    int patId = comboAppPatient->currentData().toInt();
    int slotId = comboAppSlots->currentData().toInt();
    if (slotId <= 0) {
        QMessageBox::warning(this, "Validation Error", "Please select a valid time slot.");
        return;
    }

    QSqlQuery q;
    q.prepare("INSERT INTO Appointments (PatientID, SlotID, Status) VALUES (:p, :s, 'Scheduled')");
    q.bindValue(":p", patId);
    q.bindValue(":s", slotId);
    if (q.exec()) {
        QSqlQuery updateSlot;
        updateSlot.prepare("UPDATE DoctorSlots SET IsBooked = 1 WHERE SlotID = :s");
        updateSlot.bindValue(":s", slotId);
        updateSlot.exec();
        QMessageBox::information(this, "Success", "Appointment booked successfully.");
        handleDoctorSelectionChanged();
    } else {
        QMessageBox::critical(this, "Database Error", q.lastError().text());
    }
}

void MainWindow::handleCreateSlot() {
    QSqlQuery query;
    query.prepare("INSERT INTO DoctorSlots (DoctorID, SlotDateTime, IsBooked) VALUES (:dId, :dt, 0)");
    query.bindValue(":dId", 1);
    query.bindValue(":dt", txtNewSlotDateTime->text());

    if (query.exec()) {
        QMessageBox::information(this, "Success", "New availability schedule added.");
        txtNewSlotDateTime->clear();
    } else {
        QMessageBox::critical(this, "Database Error", query.lastError().text());
    }
}

void MainWindow::handleCreatePrescription() {
    QSqlQuery query;
    query.prepare("INSERT INTO Prescriptions (PatientID, DoctorID, Medication, Dosage) VALUES (:p, :d, :m, :ds)");
    query.bindValue(":p", txtPrescPatientId->text().toInt());
    query.bindValue(":d", txtPrescDocId->text().toInt());
    query.bindValue(":m", txtMedication->text());
    query.bindValue(":ds", txtDosage->text());

    if (query.exec()) {
        QMessageBox::information(this, "Success", "Prescription issued successfully.");
        txtPrescPatientId->clear();
        txtPrescDocId->clear();
        txtMedication->clear();
        txtDosage->clear();
    } else {
        QMessageBox::critical(this, "Database Error", query.lastError().text());
    }
}

void MainWindow::onRegisterBed() {
    QSqlQuery query;
    query.prepare("INSERT INTO Beds (BedNumber, DepartmentID, IsAvailable) VALUES (:num, :dept, 1)");
    query.bindValue(":num", txtBedNum->text().toInt());
    query.bindValue(":dept", txtBedDeptId->text().toInt());

    if (query.exec()) {
        QMessageBox::information(this, "Success", "New bed registered successfully.");
        txtBedNum->clear();
        txtBedDeptId->clear();
    } else {
        QMessageBox::critical(this, "Database Error", query.lastError().text());
    }
}

void MainWindow::onRegisterLabTest() {
    QSqlQuery query;
    query.prepare("INSERT INTO Lab_Tests (PatientID, DoctorID, TestName, Result) VALUES (:pId, :dId, :name, :res)");
    query.bindValue(":pId", txtLabPatId->text().toInt());
    query.bindValue(":dId", txtLabDocId->text().toInt());
    query.bindValue(":name", txtTestName->text());
    query.bindValue(":res", txtLabResult->text());

    if (query.exec()) {
        QMessageBox::information(this, "Success", "Lab test result submitted.");
        txtLabPatId->clear();
        txtLabDocId->clear();
        txtTestName->clear();
        txtLabResult->clear();
    } else {
        QMessageBox::critical(this, "Database Error", query.lastError().text());
    }
}

// Empty placeholders as requested to avoid linker errors
void MainWindow::showPatientAdmissionWindow() {}
void MainWindow::showInpatientWindow() {}
void MainWindow::showBillingWindow() {}
void MainWindow::showWalkInAppWindow() {
    // ایجاد یک نمونه از فرم نوبت‌دهی آنلاین
    // با ارسال 'this' به عنوان والد، پنجره به درستی مدیریت می‌شود
    OnlineAppointment *appWindow = new OnlineAppointment(this);

    // نمایش پنجره به صورت مودال (یعنی تا وقتی این پنجره باز است، کاربر نمی‌تواند به پنجره اصلی دست بزند)
    appWindow->exec();

    // پس از بسته شدن پنجره، حافظه آن را آزاد می‌کنیم
    delete appWindow;
}
void MainWindow::showMedicalRecordsWindow() {
    // ایجاد یک پنجره دیالوگ جدید برای نمایش سوابق بیمار به منشی
    QDialog *recordsDialog = new QDialog(this);
    recordsDialog->setWindowTitle("Patient Medical Records Viewer");
    recordsDialog->setMinimumSize(600, 400);

    QVBoxLayout *dialogLayout = new QVBoxLayout(recordsDialog);

    // بخش سرچ و لود کردن اطلاعات
    QHBoxLayout *searchLayout = new QHBoxLayout();
    txtSearchRecordPatientIdRec = new QLineEdit(recordsDialog);
    txtSearchRecordPatientIdRec->setPlaceholderText("Enter Patient ID to look up history...");

    QPushButton *btnSearchRecordsRec = new QPushButton("Search History", recordsDialog);
    btnSearchRecordsRec->setStyleSheet("background-color: #0284c7; color: white; font-weight: bold; padding: 6px;");

    searchLayout->addWidget(new QLabel("Patient ID:", recordsDialog));
    searchLayout->addWidget(txtSearchRecordPatientIdRec);
    searchLayout->addWidget(btnSearchRecordsRec);
    dialogLayout->addLayout(searchLayout);

    // جدول سوابق بیماری
    tableMedicalRecordsRec = new QTableWidget(recordsDialog);
    tableMedicalRecordsRec->setColumnCount(5);
    tableMedicalRecordsRec->setHorizontalHeaderLabels({"Record ID", "App ID", "Doctor ID", "Diagnosis", "Treatment"});
    tableMedicalRecordsRec->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    tableMedicalRecordsRec->setEditTriggers(QAbstractItemView::NoEditTriggers); // منشی فقط می‌تواند ببیند و تغییر ندهد
    dialogLayout->addWidget(tableMedicalRecordsRec);

    // اتصال دکمه سرچ این پنجره به تابع واکشی اطلاعات از دیتابیس
    connect(btnSearchRecordsRec, &QPushButton::clicked, this, &MainWindow::handleSearchMedicalRecordsRec);

    recordsDialog->exec(); // باز کردن پنجره به صورت مودال
}
void MainWindow::loadAdmissionHistory() {}

MainWindow::~MainWindow() {}

// ======================================================================
// ۳. پیاده‌سازی متدهای مدیریت و بازرزرواسیون آنلاین نوبت‌ها (قابلیت‌های جدید)
// ======================================================================

void MainWindow::loadPatientAppointments(int patientId) {
    tableAppointments->setRowCount(0);
    QSqlQuery query;
    query.prepare("SELECT A.AppointmentID, D.FirstName, S.SlotDateTime "
                  "FROM Appointments A "
                  "JOIN DoctorSlots S ON A.SlotID = S.SlotID "
                  "JOIN Doctors D ON S.DoctorID = D.DoctorID "
                  "WHERE A.PatientID = :pId");
    query.bindValue(":pId", patientId);

    if (query.exec()) {
        int row = 0;
        while (query.next()) {
            tableAppointments->insertRow(row);
            tableAppointments->setItem(row, 0, new QTableWidgetItem(query.value(0).toString()));
            tableAppointments->setItem(row, 1, new QTableWidgetItem(query.value(1).toString()));
            tableAppointments->setItem(row, 2, new QTableWidgetItem(query.value(2).toString()));
            row++;
        }
        if (row == 0) {
            QMessageBox::information(this, "Search Result", "No appointments found for this patient.");
        }
    } else {
        QMessageBox::critical(this, "Database Error", query.lastError().text());
    }
}

void MainWindow::handleSearchPatientAppointments() {
    int patId = txtSearchPatientId->text().toInt();
    if (patId <= 0) {
        QMessageBox::warning(this, "Validation Error", "Please enter a valid Patient ID.");
        return;
    }
    loadPatientAppointments(patId);
}

void MainWindow::handleDeleteAppointment() {
    int row = tableAppointments->currentRow();
    if (row == -1) {
        QMessageBox::warning(this, "Selection Error", "Please select an appointment from the table first.");
        return;
    }

    int appId = tableAppointments->item(row, 0)->text().toInt();

    int slotId = -1;
    QSqlQuery qSlot;
    qSlot.prepare("SELECT SlotID FROM Appointments WHERE AppointmentID = :id");
    qSlot.bindValue(":id", appId);
    if (qSlot.exec() && qSlot.next()) {
        slotId = qSlot.value(0).toInt();
    }

    QSqlQuery query;
    query.prepare("DELETE FROM Appointments WHERE AppointmentID = :id");
    query.bindValue(":id", appId);

    if (query.exec()) {
        if (slotId != -1) {
            QSqlQuery updateSlot;
            updateSlot.prepare("UPDATE DoctorSlots SET IsBooked = 0 WHERE SlotID = :slotId");
            updateSlot.bindValue(":slotId", slotId);
            updateSlot.exec();
        }
        QMessageBox::information(this, "Success", "Appointment canceled and slot released successfully.");
        handleSearchPatientAppointments();
    } else {
        QMessageBox::critical(this, "Database Error", query.lastError().text());
    }
}

void MainWindow::handleRescheduleAppointment() {
    int row = tableAppointments->currentRow();
    if (row == -1) {
        QMessageBox::warning(this, "Selection Error", "Please select an appointment to reschedule.");
        return;
    }

    // ۱. ابتدا نوبت فعلی را حذف می‌کند
    handleDeleteAppointment();

    // ۲. پنجره زمان‌بندی آنلاین جدید را باز می‌کند
    OnlineAppointment appWindow(this);
    appWindow.exec();
}

// تابع جستجو و نمایش سوابق درمانی یک بیمار در جدول
void MainWindow::handleSearchMedicalRecords() {
    int patId = txtSearchRecordPatientId->text().toInt();
    if (patId <= 0) {
        QMessageBox::warning(this, "Validation Error", "Please enter a valid Patient ID.");
        return;
    }

    tableMedicalRecords->setRowCount(0); // خالی کردن جدول قبلی

    QSqlQuery query;
    // کوئری بر اساس ساختار پایگاه داده و برگرداندن آخرین سوابق ثبت شده
    query.prepare("SELECT RecordID, DoctorID, Diagnosis, Treatment FROM MedicalRecords WHERE PatientID = :pId ORDER BY RecordID DESC");
    query.bindValue(":pId", patId);

    if (query.exec()) {
        int row = 0;
        while (query.next()) {
            tableMedicalRecords->insertRow(row);
            tableMedicalRecords->setItem(row, 0, new QTableWidgetItem(query.value(0).toString()));
            tableMedicalRecords->setItem(row, 1, new QTableWidgetItem(query.value(1).toString()));
            tableMedicalRecords->setItem(row, 2, new QTableWidgetItem(query.value(2).toString()));
            tableMedicalRecords->setItem(row, 3, new QTableWidgetItem(query.value(3).toString()));
            row++;
        }
        if (row == 0) {
            QMessageBox::information(this, "No Records", "No medical history found for this patient.");
        }
    } else {
        QMessageBox::critical(this, "Database Error", "Failed to fetch records: " + query.lastError().text());
    }
}

// تابع ذخیره پرونده درمانی جدید توسط پزشک
void MainWindow::handleSaveMedicalRecord() {
    int patId = txtRecordPatientId->text().toInt();
    int docId = txtRecordDocId->text().toInt();
    QString diagnosis = txtRecordDiagnosis->text().trimmed();
    QString treatment = txtRecordTreatment->text().trimmed();
    // دریافت تاریخ امروز سیستم جهت ثبت تاریخ پرونده
    QString dateStr = QDateTime::currentDateTime().toString("yyyy-MM-dd");

    // اعتبارسنجی فیلدهای اجباری
    if (patId <= 0 || docId <= 0 || diagnosis.isEmpty()) {
        QMessageBox::warning(this, "Validation Error", "Patient ID, Doctor ID and Diagnosis are required fields.");
        return;
    }

    QSqlQuery query;
    query.prepare("INSERT INTO MedicalRecords (PatientID, DoctorID, Diagnosis, Treatment, RecordDate) "
                  "VALUES (:pId, :dId, :diag, :treat, :date)");
    query.bindValue(":pId", patId);
    query.bindValue(":dId", docId);
    query.bindValue(":diag", diagnosis);
    query.bindValue(":treat", treatment);
    query.bindValue(":date", dateStr);

    if (query.exec()) {
        QMessageBox::information(this, "Success", "Medical record saved successfully.");

        // پاک کردن فرم بعد از ثبت موفق
        txtRecordPatientId->clear();
        txtRecordDiagnosis->clear();
        txtRecordTreatment->clear();

        // به صورت خودکار جدول بالا را رفرش می‌کند تا پزشک تغییرات را ببیند
        txtSearchRecordPatientId->setText(QString::number(patId));
        handleSearchMedicalRecords();
    } else {
        QMessageBox::critical(this, "Database Error", "Failed to save record: " + query.lastError().text());
    }

}

// 🟢 ۱. تابع سرچ سوابق مخصوص پنل پزشک (اصلاح شده)
void MainWindow::handleSearchMedicalRecordsDoc() {
    if (!txtSearchRecordPatientIdDoc || !tableMedicalRecordsDoc) return;

    int patId = txtSearchRecordPatientIdDoc->text().toInt();
    if (patId <= 0) {
        QMessageBox::warning(this, "Error", "Please enter a valid Patient ID.");
        return;
    }

    tableMedicalRecordsDoc->setRowCount(0); // ریست کردن جدول

    QSqlQuery query;
    query.prepare("SELECT RecordID, AppointmentID, DoctorID, Diagnosis, Treatment FROM MedicalRecords WHERE PatientID = :pId ORDER BY RecordID DESC");
    query.bindValue(":pId", patId);

    if (query.exec()) {
        int row = 0;
        while (query.next()) {
            tableMedicalRecordsDoc->insertRow(row);
            for(int i = 0; i < 5; ++i) {
                tableMedicalRecordsDoc->setItem(row, i, new QTableWidgetItem(query.value(i).toString()));
            }
            row++;
        }
        if (row == 0) {
            QMessageBox::information(this, "Info", "No medical history found for this patient.");
        }
    } else {
        QMessageBox::critical(this, "Database Error", "Failed to fetch records: " + query.lastError().text());
    }
}

// ۲. تابع سرچ سوابق مخصوص پنل منشی (فقط خواندنی)
void MainWindow::handleSearchMedicalRecordsRec() {
    int patId = txtSearchRecordPatientIdRec->text().toInt();
    if (patId <= 0) { QMessageBox::warning(this, "Error", "Please enter a valid Patient ID."); return; }

    tableMedicalRecordsRec->setRowCount(0);
    QSqlQuery query;
    query.prepare("SELECT RecordID, AppointmentID, DoctorID, Diagnosis, Treatment FROM MedicalRecords WHERE PatientID = :pId ORDER BY RecordID DESC");
    query.bindValue(":pId", patId);

    if (query.exec()) {
        int row = 0;
        while (query.next()) {
            tableMedicalRecordsRec->insertRow(row);
            for(int i=0; i<5; ++i)
                tableMedicalRecordsRec->setItem(row, i, new QTableWidgetItem(query.value(i).toString()));
            row++;
        }
        if (row == 0) QMessageBox::information(this, "Info", "No medical history found.");
    }
}
