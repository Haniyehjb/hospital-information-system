#include "receptionpanel.h"

ReceptionPanel::ReceptionPanel(QWidget *parent)
    : QWidget(parent)
{
    mainLayout = new QVBoxLayout(this);
    mainLayout->setSpacing(15);
    mainLayout->setContentsMargins(30, 30, 30, 30);

    lblWelcome = new QLabel("Receptionist Panel - Quick Actions", this);
    lblWelcome->setStyleSheet("font-size: 16px; font-weight: bold; color: #1e3a8a; margin-bottom: 10px;");
    lblWelcome->setAlignment(Qt::AlignCenter);
    mainLayout->addWidget(lblWelcome);

    // ۱. دکمه صورت حساب
    btnBilling = new QPushButton("💰 Billing & Invoices (صورت حساب)", this);
    btnBilling->setStyleSheet("background-color: #3b82f6; color: white; font-weight: bold; font-size: 14px; padding: 12px; border-radius: 6px;");
    mainLayout->addWidget(btnBilling);

    // ۲. دکمه گرفتن نوبت حضوری
    btnInPersonApp = new QPushButton("📅 Walk-in Appointment (گرفتن نوبت حضوری)", this);
    btnInPersonApp->setStyleSheet("background-color: #10b981; color: white; font-weight: bold; font-size: 14px; padding: 12px; border-radius: 6px;");
    mainLayout->addWidget(btnInPersonApp);

    // ۳. دکمه تشکیل پرونده / مشاهده پرونده بیمار
    btnPatientRecord = new QPushButton("👤 Patient Medical Record (تشکیل / مشاهده پرونده)", this);
    btnPatientRecord->setStyleSheet("background-color: #f59e0b; color: white; font-weight: bold; font-size: 14px; padding: 12px; border-radius: 6px;");
    mainLayout->addWidget(btnPatientRecord);

    mainLayout->addStretch(); // فاصله انداز پایین برای زیبایی

    // متصل کردن سیگنال‌ها به اسلات‌ها
    connect(btnBilling, &QPushButton::clicked, this, &ReceptionPanel::onBillingClicked);
    connect(btnInPersonApp, &QPushButton::clicked, this, &ReceptionPanel::onInPersonAppClicked);
    connect(btnPatientRecord, &QPushButton::clicked, this, &ReceptionPanel::onPatientRecordClicked);
}

void ReceptionPanel::onBillingClicked() {
    QMessageBox::information(this, "Billing System", "Opening Billing & Financial Module...");
    // کدهای مربوط به تراکنش‌های مالی یا دیتابیس صورت‌حساب را اینجا بنویسید
}

void ReceptionPanel::onInPersonAppClicked() {
    QMessageBox::information(this, "Appointment System", "Opening In-Person Appointment Scheduler...");
    // کدهای باز کردن فرم نوبت‌دهی حضوری
}

void ReceptionPanel::onPatientRecordClicked() {
    QMessageBox::information(this, "Patient Records", "Opening Patient Electronic Health Records (EHR)...");
    // کدهای سرچ یا تشکیل پرونده دیتابیس
}
