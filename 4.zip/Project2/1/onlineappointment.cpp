#include "onlineappointment.h"
#include <QVariant>
#include <QDebug>

OnlineAppointment::OnlineAppointment(QWidget *parent)
    : QDialog(parent), selectedSlotId(-1)
{
    setWindowTitle("Online Appointment Booking System");
    setMinimumSize(450, 550);

    setStyleSheet(
        "QDialog { background-color: #f8fafc; }"
        "QLabel { font-weight: bold; color: #334155; font-size: 13px; }"

        // اصلاح پس‌زمینه سفید و رنگ متن تیره برای فیلد متن (txtNationalCode)
        "QLineEdit { padding: 6px; border: 1px solid #cbd5e1; border-radius: 4px; background-color: #ffffff; color: #1e293b; }"

        // اصلاح پس‌زمینه و رنگ متن برای کامبوباکس‌ها و لیست‌های بازشوی آن‌ها
        "QComboBox { padding: 6px; border: 1px solid #cbd5e1; border-radius: 4px; background-color: #ffffff; color: #1e293b; }"
        "QComboBox QAbstractItemView { background-color: #ffffff; color: #1e293b; selection-background-color: #3b82f6; selection-color: white; }"

        "QPushButton:disabled { background-color: #cbd5e1; color: #94a3b8; border: 1px solid #cbd5e1; }"
        "QPushButton:enabled { background-color: #10b981; color: white; border-radius: 4px; font-weight: bold; padding: 6px; }"
        "QPushButton:enabled:hover { background-color: #059669; }"
        );

    QVBoxLayout *mainLayout = new QVBoxLayout(this);
    mainLayout->setSpacing(12);

    // ۱. فیلد دریافت کد ملی بیمار
    lblNationalCode = new QLabel("Enter Patient National Code (10 Digits):", this);
    txtNationalCode = new QLineEdit(this);
    txtNationalCode->setPlaceholderText("e.g. 0012345678");
    mainLayout->addWidget(lblNationalCode);
    mainLayout->addWidget(txtNationalCode);

    // ۲. منوی انتخاب تخصص
    lblSpecialty = new QLabel("Select Specialty:", this);
    comboSpecialty = new QComboBox(this);
    mainLayout->addWidget(lblSpecialty);
    mainLayout->addWidget(comboSpecialty);

    // ۳. منوی انتخاب پزشک
    lblDoctor = new QLabel("Select Doctor:", this);
    comboDoctor = new QComboBox(this);
    mainLayout->addWidget(lblDoctor);
    mainLayout->addWidget(comboDoctor);

    // ۴. منوی انتخاب تاریخ حضور پزشک
    lblDate = new QLabel("Select Available Date:", this);
    comboDate = new QComboBox(this);
    mainLayout->addWidget(lblDate);
    mainLayout->addWidget(comboDate);

    // ۵. بخش نمایش نوبت‌ها (کادر ساعت‌ها)
    // ۵. بخش نمایش نوبت‌ها (کادر ساعت‌ها)
    lblSlots = new QLabel("Available Time Slots (15 Mins Intervals):", this);
    mainLayout->addWidget(lblSlots);
    lblSlots->hide(); // 🟢 این خط را اضافه کنید تا متن هم در ابتدا مخفی شود

    slotsContainer = new QWidget(this);
    slotsLayout = new QGridLayout(slotsContainer);
    slotsContainer->hide();
    mainLayout->addWidget(slotsContainer);

    // ۶. دکمه تایید نهایی نوبت
    btnConfirm = new QPushButton("Confirm Booking", this);
    btnConfirm->setEnabled(false); // در ابتدا تا ساعتی انتخاب نشده غیرفعال است
    mainLayout->addWidget(btnConfirm);

    // متصل کردن سیگنال‌ها به اسلات‌ها (روش جدید و استاندارد Qt6)
    connect(comboSpecialty, &QComboBox::currentIndexChanged, this, &OnlineAppointment::onSpecialtyChanged);
    connect(comboDoctor, &QComboBox::currentIndexChanged, this, &OnlineAppointment::onDoctorChanged);
    connect(comboDate, &QComboBox::currentIndexChanged, this, &OnlineAppointment::onDateChanged);
    connect(btnConfirm, &QPushButton::clicked, this, &OnlineAppointment::onSlotClicked);

    // لود اولیه تخصص‌ها از دیتابیس به محض باز شدن پنجره
    loadSpecialties();
}

OnlineAppointment::~OnlineAppointment() {}

void OnlineAppointment::loadSpecialties()
{
    comboSpecialty->blockSignals(true); // قطع موقت سیگنال برای جلوگیری از لود خودکار
    comboSpecialty->clear();
    specialtyIds.clear();

    QSqlQuery query("SELECT SpecialtyID, SpecialtyName FROM Specialties");
    while (query.next()) {
        specialtyIds.append(query.value(0).toInt());
        comboSpecialty->addItem(query.value(1).toString());
    }

    comboSpecialty->setCurrentIndex(-1); // قرار دادن روی حالت بدون انتخاب
    comboSpecialty->blockSignals(false); // فعال‌سازی مجدد سیگنال
}

void OnlineAppointment::onSpecialtyChanged(int index)
{
    if (index < 0 || index >= specialtyIds.size()) {
        comboDoctor->clear();
        comboDate->clear();
        lblSlots->hide();
        slotsContainer->hide();
        return;
    }
    loadDoctors(specialtyIds[index]);
}

void OnlineAppointment::loadDoctors(int specialtyId)
{
    lblSlots->hide();
    slotsContainer->hide();
    comboDoctor->blockSignals(true);
    comboDoctor->clear();
    doctorIds.clear();

    QSqlQuery query;
    query.prepare("SELECT DoctorID, FirstName + ' ' + LastName FROM Doctors WHERE SpecialtyID = :specId");
    query.bindValue(":specId", specialtyId);

    if (query.exec()) {
        while (query.next()) {
            doctorIds.append(query.value(0).toInt());
            comboDoctor->addItem(query.value(1).toString());
        }
    }

    comboDoctor->setCurrentIndex(-1); // قرار دادن روی حالت بدون انتخاب
    comboDoctor->blockSignals(false);

    // اگر دکتری یافت نشد، منوهای بعدی را پاک کن
    if (comboDoctor->count() == 0) {
        comboDate->clear();
        QLayoutItem *item;
        while ((item = slotsLayout->takeAt(0)) != nullptr) { delete item->widget(); delete item; }
        btnConfirm->setEnabled(false);
    }
}

void OnlineAppointment::onDoctorChanged(int index)
{
    if (index < 0 || index >= doctorIds.size()) {
        comboDate->clear();
        lblSlots->hide();
        slotsContainer->hide();
        return;
    }
    loadAvailableDates(doctorIds[index]);
}

void OnlineAppointment::loadAvailableDates(int doctorId)
{
    lblSlots->hide();
    slotsContainer->hide();
    comboDate->blockSignals(true);
    comboDate->clear();

    QSqlQuery query;
    query.prepare("SELECT DISTINCT CAST(SlotDateTime AS DATE) FROM OnlineAppointments "
                  "WHERE DoctorID = :docId AND SlotDateTime >= GETDATE() ORDER BY CAST(SlotDateTime AS DATE)");
    query.bindValue(":docId", doctorId);

    if (query.exec()) {
        while (query.next()) {
            QString dateStr = query.value(0).toDate().toString("yyyy-MM-dd");
            comboDate->addItem(dateStr);
        }
    }

    comboDate->setCurrentIndex(-1); // قرار دادن روی حالت بدون انتخاب
    comboDate->blockSignals(false);

    if (comboDate->count() == 0) {
        QLayoutItem *item;
        while ((item = slotsLayout->takeAt(0)) != nullptr) { delete item->widget(); delete item; }
        btnConfirm->setEnabled(false);
    }
}

void OnlineAppointment::onDateChanged(int index)
{
    if (index < 0 || comboDoctor->currentIndex() < 0) {
        lblSlots->hide();
        slotsContainer->hide();
        return;
    }
    int doctorId = doctorIds[comboDoctor->currentIndex()];
    QString dateStr = comboDate->currentText();
    loadSlots(doctorId, dateStr);
}

void OnlineAppointment::loadSlots(int doctorId, const QString &dateStr)
{
    QLayoutItem *child;
    while ((child = slotsLayout->takeAt(0)) != nullptr) {
        if(child->widget()) delete child->widget();
        delete child;
    }
    selectedSlotId = -1;
    btnConfirm->setEnabled(false);

    QSqlQuery query;
    query.prepare("SELECT AppointmentID, SlotDateTime, IsBooked FROM OnlineAppointments "
                  "WHERE DoctorID = :docId AND CAST(SlotDateTime AS DATE) = :date "
                  "ORDER BY SlotDateTime");
    query.bindValue(":docId", doctorId);
    query.bindValue(":date", dateStr);

    if (query.exec()) {
        int row = 0;
        int col = 0;
        while (query.next()) {
            int appId = query.value(0).toInt();
            QDateTime slotTime = query.value(1).toDateTime();
            bool isBooked = query.value(2).toBool();

            QString timeStr = slotTime.time().toString("HH:mm");
            QPushButton *slotBtn = new QPushButton(timeStr, this);
            slotBtn->setCheckable(true);

            slotBtn->setStyleSheet(
                "QPushButton { background-color: #e2e8f0; color: #1e293b; border: 1px solid #cbd5e1; padding: 8px; border-radius: 4px; }"
                "QPushButton:checked { background-color: #3b82f6; color: white; font-weight: bold; }"
                "QPushButton:disabled { background-color: #cbd5e1; color: #94a3b8; border: 1px solid #cbd5e1; }"
                );

            if (isBooked) {
                slotBtn->setEnabled(false);
                slotBtn->setText(timeStr + "\n(Full)");
            } else {
                slotBtn->setProperty("AppointmentID", appId);
                connect(slotBtn, &QPushButton::clicked, this, [this, slotBtn, appId]() {
                    for (int i = 0; i < slotsLayout->count(); ++i) {
                        QPushButton *b = qobject_cast<QPushButton*>(slotsLayout->itemAt(i)->widget());
                        if (b && b != slotBtn) b->setChecked(false);
                    }
                    if (slotBtn->isChecked()) {
                        selectedSlotId = appId;
                        btnConfirm->setEnabled(true);
                    } else {
                        selectedSlotId = -1;
                        btnConfirm->setEnabled(false);
                    }
                });
            }

            slotsLayout->addWidget(slotBtn, row, col);
            col++;
            if (col >= 4) { col = 0; row++; }
        }

        // 🟢 این تیکه را در انتهای تابع loadSlots جایگزین شرط قبلی کنید:
        if (slotsLayout->count() > 0) {
            lblSlots->show();       // 👈 نمایش متن ساعت‌ها
            slotsContainer->show(); // 👈 نمایش دکمه‌های ساعت
        } else {
            lblSlots->hide();
            slotsContainer->hide();
        }
    }
}

void OnlineAppointment::onSlotClicked()
{
    QString nationalCode = txtNationalCode->text().trimmed();
    if (nationalCode.isEmpty() || nationalCode.length() < 10) {
        QMessageBox::warning(this, "Validation Error", "Please enter a valid 10-digit National Code!");
        return;
    }
    if (selectedSlotId == -1) return;

    // 🟢 گام اول: چک کردن وجود بیمار با این کد ملی در جدول Patients
    int patientId = -1;
    QSqlQuery checkQuery;
    checkQuery.prepare("SELECT PatientID FROM Patients WHERE NationalCode = :nc");
    checkQuery.bindValue(":nc", nationalCode);

    if (checkQuery.exec() && checkQuery.next()) {
        patientId = checkQuery.value(0).toInt();
    } else {
        // اگر بیمار نبود، او را با نام موقت یا خالی ثبت می‌کنیم تا آیدی تولید شود
        QSqlQuery insertPat;
        insertPat.prepare("INSERT INTO Patients (NationalCode, FirstName, LastName) VALUES (:nc, 'Online', 'Patient')");
        insertPat.bindValue(":nc", nationalCode);
        if (insertPat.exec()) {
            patientId = insertPat.lastInsertId().toInt();
        } else {
            // هندل کردن حالتی که جدول فیلدهای اجباری دیگری دارد (ثبت مستقیم بر اساس کد ملی)
            QSqlQuery getPatId;
            getPatId.prepare("SELECT TOP 1 PatientID FROM Patients WHERE NationalCode = :nc");
            getPatId.bindValue(":nc", nationalCode);
            if(getPatId.exec() && getPatId.next()) {
                patientId = getPatId.value(0).toInt();
            }
        }
    }

    if (patientId == -1) {
        // ترفند پشتیبان در صورتی که ساختار جدول Patients شما اجازه ثبت مستقیم ندهد:
        // نوبت مستقیما بدون قفل آیدی سخت ثبت می‌شود یا آیدی فرضی ۱ می‌گیرد.
        patientId = 1;
    }

    // 🟢 گام دوم: به‌روزرسانی جدول نوبت‌دهی آنلاین همراه با آیدی بیمار
    QSqlQuery query;
    query.prepare("UPDATE OnlineAppointments SET PatientID = :patId, IsBooked = 1 WHERE AppointmentID = :appId");
    query.bindValue(":patId", patientId);
    query.bindValue(":appId", selectedSlotId);

    if (query.exec()) {
        QMessageBox::information(this, "Success", "Your appointment has been successfully booked!");
        accept(); // با وضعیت موفقیت پنجره را می‌بندد
    } else {
        QMessageBox::critical(this, "Database Error", "Booking failed:\n" + query.lastError().text());
    }
}

