#ifndef ONLINEAPPOINTMENT_H
#define ONLINEAPPOINTMENT_H

#include <QDialog>
#include <QComboBox>
#include <QLineEdit>
#include <QPushButton>
#include <QVBoxLayout>
#include <QGridLayout>
#include <QLabel>
#include <QSqlQuery>
#include <QSqlError>
#include <QMessageBox>
#include <QDateTime>
#include <QVector>

class OnlineAppointment : public QDialog
{
    Q_OBJECT

public:
    explicit OnlineAppointment(QWidget *parent = nullptr);
    ~OnlineAppointment();

private slots:
    void onSpecialtyChanged(int index);
    void onDoctorChanged(int index);
    void onDateChanged(int index);
    void onSlotClicked();

private:
    void loadSpecialties();
    void loadDoctors(int specialtyId);
    void loadAvailableDates(int doctorId);
    void loadSlots(int doctorId, const QString &dateStr);

    QLabel *lblSpecialty;
    QComboBox *comboSpecialty;

    QLabel *lblDoctor;
    QComboBox *comboDoctor;

    QLabel *lblDate;
    QComboBox *comboDate;

    QLabel *lblNationalCode;
    QLineEdit *txtNationalCode; // 🟢 فیلد جدید برای دریافت کد ملی بیمار

    QLabel *lblSlots;
    QWidget *slotsContainer;
    QGridLayout *slotsLayout;

    QPushButton *btnConfirm;

    QVector<int> specialtyIds;
    QVector<int> doctorIds;
    int selectedSlotId;
};

#endif // ONLINEAPPOINTMENT_H
