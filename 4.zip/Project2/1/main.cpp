#include "mainwindow.h"
#include <QApplication>
#include <QSqlDatabase>
#include <QSqlError>
#include "welcome.h"
#include <QMessageBox>

bool connectToHospitalDB() {
    QSqlDatabase db = QSqlDatabase::addDatabase("QODBC");

    QString connectionString = "DRIVER={SQL Server};"
                               "SERVER=localhost\\SQLEXPRESS;" // سرور نیما و روژینا
                               "DATABASE=Hospital_DB;"
                               "Trusted_Connection=Yes;";

    db.setDatabaseName(connectionString);

    if (!db.open()) {
        QMessageBox::critical(nullptr, "Database Error",
                              "Failed to connect to SQL Server:\n" + db.lastError().text());
        return false;
    }
    return true;
}

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

    // 🟢 اصلاح اصلی اینجاست: ابتدا به دیتابیس متصل می‌شویم
    if (!connectToHospitalDB()) {
        return -1; // اگر به دیتابیس وصل نشد، برنامه کلاً باز نشود و ارور بدهد
    }

    Welcome portal;
    if (portal.exec() == QDialog::Accepted) {
        int userRole = portal.getFinalRoleIndex();

        // باز شدن پنجره اصلی با دسترسی‌های فیلتر شده
        MainWindow w(userRole);
        w.show();

        return a.exec();
    }

    return 0;
}
