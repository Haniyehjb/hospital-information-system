#ifndef WELCOME_H
#define WELCOME_H

#include <QDialog>
#include <QPushButton>
#include <QComboBox>
#include <QVBoxLayout>
#include <QLabel>

class Welcome : public QDialog
{
    Q_OBJECT

public:
    explicit Welcome(QWidget *parent = nullptr);
    int getFinalRoleIndex() const; // خروجی: کد نقش نهایی برای ورود به سیستم

private slots:
    void onPatientClicked();    // کلیک روی نوبت آنلاین
    void onStaffClicked();      // کلیک روی کادر درمان
    void onLoginStaffClicked(); // کلیک روی دکمه ورود نهایی کادر درمان

private:
    // المان‌های منوی اول
    QLabel *lblTitle;
    QPushButton *btnPatient;
    QPushButton *btnStaff;

    // المان‌های منوی دوم
    QLabel *lblStaffSelect;
    QComboBox *comboStaffRoles;
    QPushButton *btnGroupEnter;

    QVBoxLayout *mainLayout;
    int finalRoleIndex; // 0: بیمار، 1: پذیرش، 2: پزشک، 3: آزمایشگاه، 4: مدیر
};

#endif // WELCOME_H
