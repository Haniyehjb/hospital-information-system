#include "welcome.h"
#include "onlineappointment.h"

Welcome::Welcome(QWidget *parent)
    : QDialog(parent), finalRoleIndex(-1)
{
    setWindowTitle("Hospital HIS - Welcome Portal");
    setFixedSize(360, 240);

    mainLayout = new QVBoxLayout(this);

    lblTitle = new QLabel("Welcome to Hospital HIS Portal\nPlease select your destination:", this);
    lblTitle->setStyleSheet("font-size: 14px; font-weight: bold; color: #0284c7; margin-bottom: 10px;");
    lblTitle->setAlignment(Qt::AlignCenter);

    // دکمه‌های منوی اول
    btnPatient = new QPushButton("Online Appointment (Patients)", this);
    btnStaff = new QPushButton("Medical Staff Portal", this);

    // تغییر رنگ دکمه بیمار برای زیبایی و تفکیک
    btnPatient->setStyleSheet("background-color: #10b981; color: white; font-weight: bold;");

    mainLayout->addWidget(lblTitle);
    mainLayout->addWidget(btnPatient);
    mainLayout->addWidget(btnStaff);

    // ساخت المان‌های منوی دوم (در ابتدا مخفی هستند)
    lblStaffSelect = new QLabel("Select your medical department role:", this);
    comboStaffRoles = new QComboBox(this);
    comboStaffRoles->addItem("Receptionist / Admission");
    comboStaffRoles->addItem("Doctor");
    comboStaffRoles->addItem("Laboratory Technician");
    comboStaffRoles->addItem("IT / Admin System");

    btnGroupEnter = new QPushButton("Verify & Enter", this);

    lblStaffSelect->hide();
    comboStaffRoles->hide();
    btnGroupEnter->hide();

    mainLayout->addWidget(lblStaffSelect);
    mainLayout->addWidget(comboStaffRoles);
    mainLayout->addWidget(btnGroupEnter);

    // متصل کردن سیگنال‌ها به اسلات‌ها
    connect(btnPatient, &QPushButton::clicked, this, &Welcome::onPatientClicked);
    connect(btnStaff, &QPushButton::clicked, this, &Welcome::onStaffClicked);
    connect(btnGroupEnter, &QPushButton::clicked, this, &Welcome::onLoginStaffClicked);
}

void Welcome::onPatientClicked()
{
    // ۱. پنهان کردن موقت پنجره اصلی خوش‌آمدگویی
    this->hide();

    // ۲. ایجاد و نمایش پنجره نوبت‌دهی آنلاین
    OnlineAppointment onlineAppWindow(this);

    // اجرای پنجره نوبت دهی؛ برنامه منتظر می‌ماند تا بیمار کارش تمام شود
    onlineAppWindow.exec();

    // ۳. 🟢 به محض اینکه دکمه تایید نوبت زده شد و پنجره بسته شد، فرم ملی/پرسنل مجدداً نمایش داده می‌شود
     // پاک کردن فیلدها برای نفر بعدی در صورت وجود
    this->show();
}

void Welcome::onStaffClicked()
{
    // پنهان کردن منوی اول
    btnPatient->hide();
    btnStaff->hide();
    lblTitle->setText("Medical Staff Authentication");

    // نمایان کردن منوی دوم (انتخاب نقش‌ها)
    lblStaffSelect->show();
    comboStaffRoles->show();
    btnGroupEnter->show();
}

void Welcome::onLoginStaffClicked()
{
    // نقش‌ها را به ترتیب بعد از بیمار قرار می‌دهیم:
    // ایندکس کامبوباکس + 1 (چون 0 خودِ بیمار است)
    finalRoleIndex = comboStaffRoles->currentIndex() + 1;
    accept();
}

int Welcome::getFinalRoleIndex() const
{
    return finalRoleIndex;
}
