#ifndef RECEPTIONPANEL_H
#define RECEPTIONPANEL_H

#include <QWidget>
#include <QPushButton>
#include <QVBoxLayout>
#include <QLabel>
#include <QMessageBox>

class ReceptionPanel : public QWidget
{
    Q_OBJECT
public:
    explicit ReceptionPanel(QWidget *parent = nullptr);

signals:
    // اگر در آینده نیاز شد با MainWindow ارتباط برقرار کند
    void logoutRequested();

private slots:
    void onBillingClicked();
    void onInPersonAppClicked();
    void onPatientRecordClicked();

private:
    QLabel *lblWelcome;
    QPushButton *btnBilling;
    QPushButton *btnInPersonApp;
    QPushButton *btnPatientRecord;
    QVBoxLayout *mainLayout;
};

#endif // RECEPTIONPANEL_H
